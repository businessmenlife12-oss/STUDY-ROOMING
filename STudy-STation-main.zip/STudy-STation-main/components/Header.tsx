'use client';

import { motion } from 'motion/react';
import { Moon, Sun } from 'lucide-react';
import type { PrimaryView } from '@/lib/types';
import { BrandDeskLampEmblem } from './BrandGraphics';

interface HeaderProps {
  brandName: string;
  activeView: PrimaryView;
  darkMode: boolean;
  onSwitchView: (view: PrimaryView) => void;
  onToggleDarkMode: () => void;
}

const NAV_ITEMS: Array<{ key: PrimaryView; label: string }> = [
  { key: 'booking', label: 'Book Seat' },
  { key: 'student', label: 'Student Portal' },
  { key: 'admin', label: 'Admin' },
];

export default function Header({
  brandName,
  activeView,
  darkMode,
  onSwitchView,
  onToggleDarkMode,
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 border-b border-forest-900/10 dark:border-mustard-500/20 bg-cream/95 dark:bg-forest-950/95 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4 md:gap-8">
        {/* Zone 1: Single-line Brand Wordmark */}
        <motion.button
          type="button"
          onClick={() => onSwitchView('visitor')}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          transition={{ type: 'spring', stiffness: 400, damping: 17 }}
          className="flex items-center gap-2.5 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-forest-900 dark:focus-visible:ring-mustard-400 rounded-lg shrink-0 cursor-pointer"
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/assets/aistudio/STudy_STation_Focus_Logo_9233074a.png"
            alt={brandName}
            className="h-12 sm:h-14 w-auto object-contain"
            referrerPolicy="no-referrer"
          />
        </motion.button>

        {/* Zone 2: Clean Desktop Navigation Links */}
        <nav
          aria-label="Primary Navigation"
          className="hidden md:flex items-center gap-6 text-sm font-semibold"
        >
          {NAV_ITEMS.map((item) => {
            const isActive = activeView === item.key;
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => onSwitchView(item.key)}
                aria-current={isActive ? 'page' : undefined}
                className={`py-1.5 border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  isActive
                    ? 'border-forest-900 dark:border-mustard-400 text-forest-900 dark:text-mustard-400'
                    : 'border-transparent text-slate-600 dark:text-slate-300 hover:text-forest-900 dark:hover:text-white'
                }`}
              >
                {item.key === 'admin' ? (
                  <div className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-mustard-400/20 text-forest-900 dark:text-mustard-400 font-bold">
                    <BrandDeskLampEmblem className="w-4 h-4 shrink-0" />
                    <span className="text-[11px]">Admin</span>
                  </div>
                ) : (
                  item.label
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Theme Toggle + Single Primary CTA */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={onToggleDarkMode}
            aria-label={darkMode ? 'Switch to light theme' : 'Switch to dark theme'}
            className="w-10 h-10 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-forest-900 dark:text-mustard-400 flex items-center justify-center hover:bg-forest-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
          <button
            type="button"
            onClick={() => onSwitchView('booking')}
            className="px-4 py-2 rounded-lg bg-forest-900 hover:bg-forest-800 dark:bg-mustard-500 dark:hover:bg-mustard-400 text-white dark:text-forest-950 text-xs font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Book Seat Now
          </button>
        </div>
      </div>

      {/* Compact Mobile Navigation Row (total sticky header well below 15% mobile height) */}
      <nav
        aria-label="Mobile Navigation"
        className="md:hidden grid grid-cols-3 gap-1.5 px-3 pb-2.5 pt-2 border-t border-forest-900/5 dark:border-white/5"
      >
        {NAV_ITEMS.map((item) => {
          const isActive = activeView === item.key;
          return (
            <button
              key={item.key}
              type="button"
              onClick={() => onSwitchView(item.key)}
              aria-current={isActive ? 'page' : undefined}
              className={`px-1.5 py-1.5 rounded-md text-[11px] font-bold text-center whitespace-nowrap truncate transition-colors cursor-pointer flex items-center justify-center gap-1 ${
                isActive
                  ? 'bg-forest-900 text-white dark:bg-mustard-400 dark:text-forest-950'
                  : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-800'
              }`}
            >
              {item.key === 'admin' ? (
                <div className="flex items-center gap-1">
                  <BrandDeskLampEmblem className="w-3.5 h-3.5 shrink-0" />
                  <span>Admin</span>
                </div>
              ) : (
                item.label
              )}
            </button>
          );
        })}
      </nav>
    </header>
  );
}
