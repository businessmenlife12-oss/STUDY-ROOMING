'use client';

import React, { useState } from 'react';
import { Ban, Check, Hourglass, Lock, ShieldCheck, UserCheck, Wind } from 'lucide-react';
import type { AppState, BookingPaymentMode } from '@/lib/types';
import {
  formatSeatCode,
  getISTDateInfo,
  getSeatStatusForShift,
  getShiftDisplayName,
  getShiftPrice,
  getShiftSeatCounts,
} from '@/lib/study-station';

interface BookingViewProps {
  state: AppState;
  bookingShift: string;
  selectedSeat: number | null;
  paymentMode: BookingPaymentMode;
  onSelectShift: (shiftKey: string) => void;
  onToggleSeat: (seatNum: number) => void;
  onSelectPaymentMode: (mode: BookingPaymentMode) => void;
  onSubmitBooking: (payload: {
    name: string;
    phone: string;
    email: string;
    exam: string;
    joinedDate: string;
  }) => void;
}

export default function BookingView({
  state,
  bookingShift,
  selectedSeat,
  paymentMode,
  onSelectShift,
  onToggleSeat,
  onSelectPaymentMode,
  onSubmitBooking,
}: BookingViewProps) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [exam, setExam] = useState('UPSC / MPSC');
  const [joinedDate, setJoinedDate] = useState(() => getISTDateInfo(0).dateStr);
  const [isSwitchingShift, setIsSwitchingShift] = useState(false);

  const counts = getShiftSeatCounts(state, bookingShift);
  const fullFee = getShiftPrice(state.courses, bookingShift);
  const pg = state.paymentGateway;
  const tokenAmt = Math.min(Number(pg.tokenAmount || 99), fullFee);

  const effectiveMode: BookingPaymentMode =
    !pg.allowTokenBooking && pg.allowFullPayment
      ? 'full'
      : pg.allowTokenBooking && !pg.allowFullPayment
        ? 'partial'
        : paymentMode;

  const payableNow = effectiveMode === 'partial' ? tokenAmt : fullFee;
  const balanceLater = Math.max(0, fullFee - tokenAmt);
  const balanceDeadline = getISTDateInfo(Number(pg.balanceDeadlineDays || 7)).dateStr;

  const handleShiftClick = (key: string) => {
    setIsSwitchingShift(true);
    onSelectShift(key);
    setTimeout(() => setIsSwitchingShift(false), 180);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitBooking({
      name: name.trim(),
      phone: phone.trim(),
      email: email.trim(),
      exam,
      joinedDate: joinedDate || getISTDateInfo(0).dateStr,
    });
  };

  return (
    <section className="bg-cream dark:bg-slate-950 py-8 lg:py-12 min-h-[82vh]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {/* 4-Step Booking Progress Indicator */}
        <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800">
          <div className="grid grid-cols-4 gap-2 text-center">
            <div className="flex flex-col items-center">
              <div className="w-7 h-7 rounded-full bg-forest-900 text-mustard-400 font-mono font-bold text-xs flex items-center justify-center">
                1
              </div>
              <span className="text-[11px] font-bold text-forest-950 dark:text-white mt-1.5">
                Course / Shift
              </span>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-7 h-7 rounded-full bg-forest-900 text-mustard-400 font-mono font-bold text-xs flex items-center justify-center">
                2
              </div>
              <span className="text-[11px] font-bold text-forest-950 dark:text-white mt-1.5">
                Pick Seat
              </span>
            </div>
            <div className="flex flex-col items-center">
              <div
                className={`w-7 h-7 rounded-full font-mono font-bold text-xs flex items-center justify-center ${
                  selectedSeat
                    ? 'bg-forest-900 text-mustard-400'
                    : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                3
              </div>
              <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300 mt-1.5">
                Partial / Full Pay
              </span>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-7 h-7 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono font-bold text-xs flex items-center justify-center">
                4
              </div>
              <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 mt-1.5">
                Verified Pass
              </span>
            </div>
          </div>
          <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full mt-3 overflow-hidden">
            <div
              className="h-full bg-forest-900 dark:bg-mustard-400 rounded-full transition-all duration-300"
              style={{ width: selectedSeat ? '72%' : '38%' }}
            />
          </div>
        </div>

        {/* Live Seat Counters & Lock Info */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800">
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-forest-700 dark:text-mustard-400 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5" />
              <span>Atomic Seat Lock · {pg.lockDurationMins}-Min Hold</span>
            </p>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-forest-950 dark:text-white mt-1">
              Select Your Course / Shift & Seat
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-1">
              Selecting an available cabin places a temporary {pg.lockDurationMins}-minute hold to
              prevent double-booking during checkout.
            </p>
          </div>

          <div className="flex items-center gap-4 bg-forest-50 dark:bg-slate-800 px-5 py-3.5 rounded-xl border border-forest-900/10 dark:border-slate-700 shrink-0">
            <div className="text-center pr-4 border-r border-forest-900/15 dark:border-slate-700">
              <p
                data-testid="booking-stat-avail"
                className="text-2xl font-mono font-bold tabular-nums text-emerald-700 dark:text-emerald-400"
              >
                {counts.available}
              </p>
              <p className="text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400">
                Available
              </p>
            </div>
            <div className="text-center pr-4 border-r border-forest-900/15 dark:border-slate-700">
              <p
                data-testid="booking-stat-reserved"
                className="text-2xl font-mono font-bold tabular-nums text-crimson-600 dark:text-rose-400"
              >
                {counts.reserved}
              </p>
              <p className="text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400">
                Reserved
              </p>
            </div>
            <div className="text-center">
              <p
                data-testid="booking-stat-blocked"
                className="text-2xl font-mono font-bold tabular-nums text-slate-700 dark:text-slate-200"
              >
                {counts.blocked}
              </p>
              <p className="text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400">
                Blocked
              </p>
            </div>
          </div>
        </div>

        {/* Dynamic Course / Shift Selector */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {state.courses.map((course) => {
            const active = course.key === bookingShift;
            return (
              <button
                key={course.key}
                type="button"
                onClick={() => handleShiftClick(course.key)}
                className={`text-left p-4 rounded-xl border-2 transition-colors cursor-pointer ${
                  active
                    ? 'border-forest-900 bg-forest-900 text-white dark:border-mustard-400'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-forest-950 dark:text-white hover:border-forest-900 dark:hover:border-mustard-400'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-extrabold uppercase truncate">{course.name}</span>
                  <span
                    className={`text-xs font-mono font-bold tabular-nums ${
                      active ? 'text-mustard-400' : 'text-crimson-600 dark:text-mustard-400'
                    }`}
                  >
                    ₹{course.fee}
                  </span>
                </div>
                <p
                  className={`text-xs mt-1 ${
                    active ? 'text-forest-100' : 'text-slate-500 dark:text-slate-400'
                  }`}
                >
                  {course.schedule}
                </p>
              </button>
            );
          })}
        </div>

        {/* Interactive Seat Map + Admission Checkout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: Interactive Seat Grid */}
          <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800">
            <div className="flex flex-wrap items-center justify-between gap-3 pb-4 mb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-forest-900 dark:text-white">
                <Wind className="w-4 h-4 text-forest-700 dark:text-emerald-400" />
                <span>Step 2: Tap an Available Seat</span>
              </div>
              <div className="flex flex-wrap items-center gap-3 text-xs font-semibold text-slate-600 dark:text-slate-300">
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-emerald-100 border border-emerald-600 inline-block" />
                  Available
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-mustard-400 border border-mustard-600 inline-block" />
                  Selected
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-rose-100 border border-crimson-600/50 inline-block" />
                  Confirmed
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded bg-slate-800 inline-block" />
                  Blocked
                </span>
              </div>
            </div>

            {isSwitchingShift ? (
              <div className="grid grid-cols-5 sm:grid-cols-8 md:grid-cols-10 gap-2">
                {Array.from({ length: 20 }).map((_, idx) => (
                  <div
                    key={idx}
                    className="h-12 rounded-xl bg-slate-100 dark:bg-slate-800 animate-pulse"
                  />
                ))}
              </div>
            ) : (
              <div
                data-testid="public-seat-grid"
                className="grid grid-cols-5 sm:grid-cols-8 md:grid-cols-10 gap-2"
              >
                {Array.from({ length: state.totalSeats }, (_, idx) => idx + 1).map((seatNum) => {
                  const seatCode = formatSeatCode(seatNum);
                  const info = getSeatStatusForShift(state, seatNum, bookingShift, {
                    currentSelectedSeat: selectedSeat,
                    currentBookingShift: bookingShift,
                  });
                  const isSelected = selectedSeat === seatNum;

                  if (info.status === 'blocked') {
                    return (
                      <button
                        key={seatNum}
                        type="button"
                        disabled
                        aria-label={`${seatCode} Blocked`}
                        className="py-2.5 px-1 rounded-xl bg-slate-800 text-slate-300 text-[11px] font-mono font-bold cursor-not-allowed flex flex-col items-center justify-center min-h-[46px]"
                      >
                        <Ban className="w-3 h-3 mb-0.5 text-mustard-400" />
                        <span>{seatCode}</span>
                      </button>
                    );
                  }

                  if (info.status === 'locked') {
                    return (
                      <button
                        key={seatNum}
                        type="button"
                        disabled
                        aria-label={`${seatCode} Temporarily Locked`}
                        className="py-2.5 px-1 rounded-xl bg-amber-100 border border-amber-400 text-amber-900 text-[11px] font-mono font-bold cursor-not-allowed flex flex-col items-center justify-center min-h-[46px]"
                      >
                        <Hourglass className="w-3 h-3 mb-0.5" />
                        <span>{seatCode}</span>
                      </button>
                    );
                  }

                  if (info.status === 'reserved') {
                    return (
                      <button
                        key={seatNum}
                        type="button"
                        disabled
                        aria-label={`${seatCode} Confirmed Reservation`}
                        className="py-2.5 px-1 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-crimson-600/30 text-crimson-700 dark:text-rose-300 text-[11px] font-mono font-bold cursor-not-allowed flex flex-col items-center justify-center min-h-[46px]"
                      >
                        <UserCheck className="w-3 h-3 mb-0.5" />
                        <span>{seatCode}</span>
                      </button>
                    );
                  }

                  return (
                    <button
                      key={seatNum}
                      type="button"
                      onClick={() => onToggleSeat(seatNum)}
                      aria-label={`Select seat ${seatCode}`}
                      aria-pressed={isSelected}
                      className={`py-2.5 px-1 rounded-xl text-[11px] font-mono font-bold flex flex-col items-center justify-center min-h-[46px] transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-mustard-400 border-2 border-mustard-600 text-forest-950 shadow-md scale-[1.03]'
                          : 'bg-emerald-50 dark:bg-emerald-950/40 hover:bg-forest-900 dark:hover:bg-mustard-500 border border-emerald-500/40 text-forest-900 dark:text-emerald-200 hover:text-white dark:hover:text-forest-950'
                      }`}
                    >
                      {isSelected ? (
                        <Lock className="w-3 h-3 mb-0.5" />
                      ) : (
                        <Check className="w-3 h-3 mb-0.5 opacity-75" />
                      )}
                      <span>{seatCode}</span>
                    </button>
                  );
                })}
              </div>
            )}

            <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400 font-medium">
              <span>Individual Power Outlet at Every Desk</span>
              <span>Server-Verified Seat Allocation</span>
            </div>
          </div>

          {/* Right: Admission Checkout Form */}
          <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 lg:sticky lg:top-20">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-forest-700 dark:text-mustard-400">
                  Step 3 · Payment Choice
                </p>
                <h2 className="text-xl font-extrabold text-forest-950 dark:text-white">
                  Admission Checkout
                </h2>
              </div>
              <div
                data-testid="checkout-seat-pill"
                className="bg-forest-900 text-mustard-400 font-mono font-bold text-sm px-3.5 py-2 rounded-xl"
              >
                {selectedSeat ? formatSeatCode(selectedSeat) : 'No Seat'}
              </div>
            </div>

            <div className="bg-cream dark:bg-slate-800 rounded-xl p-4 my-4 border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
              <div className="flex justify-between gap-2">
                <span className="text-slate-500 dark:text-slate-400 font-semibold">
                  Selected Seat:
                </span>
                <span className="font-bold text-forest-950 dark:text-white">
                  {selectedSeat
                    ? `${formatSeatCode(selectedSeat)} (Locked for Checkout)`
                    : 'Tap an available green seat'}
                </span>
              </div>
              <div className="flex justify-between gap-2">
                <span className="text-slate-500 dark:text-slate-400 font-semibold">
                  Course / Shift:
                </span>
                <span className="font-bold text-forest-900 dark:text-mustard-400 text-right">
                  {getShiftDisplayName(state.courses, bookingShift)}
                </span>
              </div>
              <div className="flex justify-between gap-2">
                <span className="text-slate-500 dark:text-slate-400 font-semibold">
                  Total Admission Fee:
                </span>
                <span className="font-mono font-bold tabular-nums text-forest-950 dark:text-white">
                  ₹{fullFee} / mo
                </span>
              </div>
              {effectiveMode === 'partial' && (
                <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex justify-between gap-2">
                  <span className="text-amber-700 dark:text-amber-400 font-bold">
                    Remaining Balance Due By:
                  </span>
                  <span className="font-mono font-bold text-crimson-600 dark:text-amber-300">
                    {balanceDeadline}
                  </span>
                </div>
              )}
            </div>

            {/* Option A vs Option B Payment Selector */}
            <div className="mb-4">
              <span className="block text-xs font-bold uppercase text-forest-950 dark:text-slate-200 mb-2">
                Choose Payment Option
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {pg.allowTokenBooking && (
                  <button
                    type="button"
                    onClick={() => onSelectPaymentMode('partial')}
                    className={`text-left p-3 rounded-xl border-2 transition-colors cursor-pointer ${
                      effectiveMode === 'partial'
                        ? 'border-forest-900 bg-forest-900 text-white dark:border-mustard-400'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-forest-950 dark:text-white'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span
                        className={`text-[11px] font-extrabold uppercase ${
                          effectiveMode === 'partial' ? 'text-mustard-400' : ''
                        }`}
                      >
                        Option A: Partial
                      </span>
                      <span className="text-xs font-mono font-bold tabular-nums">
                        ₹{tokenAmt}
                      </span>
                    </div>
                    <p
                      className={`text-[11px] mt-1 ${
                        effectiveMode === 'partial'
                          ? 'text-forest-100'
                          : 'text-slate-500 dark:text-slate-400'
                      }`}
                    >
                      Hold seat · Pay ₹{balanceLater} later
                    </p>
                  </button>
                )}

                {pg.allowFullPayment && (
                  <button
                    type="button"
                    onClick={() => onSelectPaymentMode('full')}
                    className={`text-left p-3 rounded-xl border-2 transition-colors cursor-pointer ${
                      effectiveMode === 'full'
                        ? 'border-forest-900 bg-forest-900 text-white dark:border-mustard-400'
                        : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-forest-950 dark:text-white'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span
                        className={`text-[11px] font-extrabold uppercase ${
                          effectiveMode === 'full' ? 'text-mustard-400' : ''
                        }`}
                      >
                        Option B: Full Pay
                      </span>
                      <span className="text-xs font-mono font-bold tabular-nums">
                        ₹{fullFee}
                      </span>
                    </div>
                    <p
                      className={`text-[11px] mt-1 ${
                        effectiveMode === 'full'
                          ? 'text-forest-100'
                          : 'text-slate-500 dark:text-slate-400'
                      }`}
                    >
                      100% Paid · Official Receipt
                    </p>
                  </button>
                )}
              </div>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-3">
              <div>
                <label
                  htmlFor="book-name"
                  className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1"
                >
                  Student Full Name *
                </label>
                <input
                  id="book-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Pranav Deshmukh"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:border-forest-900 outline-none text-sm font-medium"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label
                    htmlFor="book-phone"
                    className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Mobile (10 Digits) *
                  </label>
                  <input
                    id="book-phone"
                    type="tel"
                    required
                    pattern="[0-9]{10}"
                    maxLength={10}
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="98XXXXXXXX"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:border-forest-900 outline-none text-sm font-mono font-bold"
                  />
                </div>
                <div>
                  <label
                    htmlFor="book-email"
                    className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Email Address *
                  </label>
                  <input
                    id="book-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="student@email.com"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:border-forest-900 outline-none text-sm font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label
                    htmlFor="book-exam"
                    className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Target Exam / Stream
                  </label>
                  <select
                    id="book-exam"
                    value={exam}
                    onChange={(e) => setExam(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-cream dark:bg-slate-800 text-forest-950 dark:text-white outline-none text-xs font-bold"
                  >
                    <option value="UPSC / MPSC">UPSC / MPSC</option>
                    <option value="NEET / JEE">NEET / JEE</option>
                    <option value="Banking / SSC">Banking / SSC</option>
                    <option value="CA / CS / Law">CA / CS / Law</option>
                    <option value="University / IT">University / IT</option>
                  </select>
                </div>
                <div>
                  <label
                    htmlFor="book-start-date"
                    className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Joining Date *
                  </label>
                  <input
                    id="book-start-date"
                    type="date"
                    required
                    value={joinedDate}
                    onChange={(e) => setJoinedDate(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-cream dark:bg-slate-800 text-forest-950 dark:text-white outline-none text-xs font-mono font-bold"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-forest-900 hover:bg-forest-800 dark:bg-mustard-500 dark:hover:bg-mustard-400 text-white dark:text-forest-950 font-bold text-sm py-3.5 rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>
                  Pay ₹{payableNow} via {pg.provider}
                </span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
