'use client';

import React, { useState } from 'react';
import {
  Ban,
  Check,
  Copy,
  CreditCard,
  Crown,
  Download,
  FileSpreadsheet,
  Globe,
  Hourglass,
  Lock,
  Play,
  Plus,
  RotateCcw,
  Save,
  Server,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Trash2,
  UserPlus,
  Users,
} from 'lucide-react';
import type { AdminTabKey, AppState, MemberRecord } from '@/lib/types';
import {
  buildCsvContent,
  diffDaysFromTodayIST,
  formatSeatCode,
  getISTDateInfo,
  getSeatStatusForShift,
  getShiftPrice,
  getShiftSeatCounts,
  getShiftShortName,
} from '@/lib/study-station';

interface AdminViewProps {
  state: AppState;
  adminOtpVerified: boolean;
  onUnlockAdmin: () => void;
  onLockAdmin: () => void;
  onUpdateState: (updater: (prev: AppState) => AppState, auditMsg?: string) => void;
  onRunReminders: () => void;
  onRenewMember: (memberId: string) => void;
  onResetDefaults: () => void;
  onToast: (msg: string) => void;
}

const ADMIN_TABS: Array<{ key: AdminTabKey; label: string }> = [
  { key: 'website', label: '1. Website & FAQs' },
  { key: 'payment', label: '2. Gateway & Refunds' },
  { key: 'seats', label: '3. Courses & Seats' },
  { key: 'available', label: '4. Vacant Seats' },
  { key: 'fulltime', label: '5. Full-Time (₹999)' },
  { key: 'expiry', label: '6. Expiry Tracker' },
  { key: 'reminders', label: '7. Students & Reminders' },
  { key: 'animations', label: '8. Motion & Audit' },
  { key: 'architecture', label: '9. SQL & API Blueprint' },
];

const SQL_SNIPPET = `CREATE TABLE courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  schedule TEXT NOT NULL,
  monthly_fee INTEGER NOT NULL CHECK (monthly_fee > 0)
);

CREATE TABLE seats (
  seat_number INTEGER PRIMARY KEY,
  is_blocked BOOLEAN DEFAULT FALSE
);

CREATE TABLE bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL,
  course_slug TEXT REFERENCES courses(slug),
  seat_number INTEGER REFERENCES seats(seat_number),
  payment_mode TEXT CHECK (payment_mode IN ('partial','full')),
  total_fee INTEGER NOT NULL,
  paid_amount INTEGER DEFAULT 0,
  balance_due INTEGER NOT NULL,
  status TEXT CHECK (status IN ('LOCKED','CONFIRMED','EXPIRED','REFUNDED')),
  lock_expires_at TIMESTAMPTZ,
  balance_deadline DATE,
  expiry_date DATE NOT NULL
);

CREATE UNIQUE INDEX idx_unique_active_seat_shift
  ON bookings (seat_number, course_slug)
  WHERE status = 'CONFIRMED';`;

const NODE_SNIPPET = `// POST /api/payments/verify (Next.js App Router)
import crypto from 'crypto';

export async function verifySignature(orderId: string, paymentId: string, sig: string) {
  const expected = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET!)
    .update(\`\${orderId}|\${paymentId}\`)
    .digest('hex');

  return expected === sig;
}`;

export default function AdminView({
  state,
  adminOtpVerified,
  onUnlockAdmin,
  onLockAdmin,
  onUpdateState,
  onRunReminders,
  onRenewMember,
  onResetDefaults,
  onToast,
}: AdminViewProps) {
  const [mobileInput, setMobileInput] = useState(state.adminMobile);
  const [generatedOtp, setGeneratedOtp] = useState<string | null>(null);
  const [otpInput, setOtpInput] = useState('');
  const [activeTab, setActiveTab] = useState<AdminTabKey>('website');

  // Local form states for Tab 1 (Website & FAQs)
  const [brandName, setBrandName] = useState(state.website.brandName);
  const [tagline, setTagline] = useState(state.website.tagline);
  const [announcement, setAnnouncement] = useState(state.website.announcement);
  const [hoursBadge, setHoursBadge] = useState(state.website.hoursBadge);
  const [phone, setPhone] = useState(state.website.phone);
  const [address, setAddress] = useState(state.website.address);
  const [newFaqQ, setNewFaqQ] = useState('');
  const [newFaqA, setNewFaqA] = useState('');

  // Tab 2 (Payment Gateway)
  const [pgProvider, setPgProvider] = useState(state.paymentGateway.provider);
  const [pgMode, setPgMode] = useState(state.paymentGateway.mode);
  const [pgKeyId, setPgKeyId] = useState(state.paymentGateway.keyId);
  const [pgUpiId, setPgUpiId] = useState(state.paymentGateway.upiId);
  const [pgTokenAmount, setPgTokenAmount] = useState(String(state.paymentGateway.tokenAmount));
  const [pgBalanceDays, setPgBalanceDays] = useState(
    String(state.paymentGateway.balanceDeadlineDays)
  );
  const [pgLockMins, setPgLockMins] = useState(String(state.paymentGateway.lockDurationMins));
  const [pgMerchantName, setPgMerchantName] = useState(state.paymentGateway.merchantName);
  const [pgAllowToken, setPgAllowToken] = useState(state.paymentGateway.allowTokenBooking);
  const [pgAllowFull, setPgAllowFull] = useState(state.paymentGateway.allowFullPayment);
  const [pgEnableUpi, setPgEnableUpi] = useState(state.paymentGateway.enableUpi);
  const [pgEnableCard, setPgEnableCard] = useState(state.paymentGateway.enableCard);
  const [pgEnableNet, setPgEnableNet] = useState(state.paymentGateway.enableNetbanking);
  const [pgEnableWallet, setPgEnableWallet] = useState(state.paymentGateway.enableWallets);

  // Tab 3 & 4 filters
  const [seatFilterShift, setSeatFilterShift] = useState('morning');
  const [vacantFilterShift, setVacantFilterShift] = useState('morning');
  const [newCourseName, setNewCourseName] = useState('');
  const [newCourseTime, setNewCourseTime] = useState('');
  const [newCourseFee, setNewCourseFee] = useState('');

  // Tab 7 (Students & Reminders)
  const [studentSearch, setStudentSearch] = useState('');
  const [walkinName, setWalkinName] = useState('');
  const [walkinPhone, setWalkinPhone] = useState('');
  const [walkinShift, setWalkinShift] = useState(state.courses[0]?.key || 'morning');
  const [walkinSeat, setWalkinSeat] = useState('');
  const [walkinExpiry, setWalkinExpiry] = useState(() => getISTDateInfo(30).dateStr);
  const [smsTemplate, setSmsTemplate] = useState(state.reminders.smsTemplate);
  const [waTemplate, setWaTemplate] = useState(state.reminders.whatsappTemplate);

  const handleSendOtp = () => {
    if (mobileInput.trim() !== state.adminMobile) {
      onToast(`Access Denied: Mobile must match registered Admin (${state.adminMobile}).`);
      return;
    }
    const otp = String(Math.floor(100000 + Math.random() * 900000));
    setGeneratedOtp(otp);
    onToast(`6-Digit OTP (${otp}) sent to Admin mobile +91 ${mobileInput.trim()}.`);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!generatedOtp || otpInput.trim() !== generatedOtp) {
      onToast('Invalid or expired OTP code.');
      return;
    }
    setOtpInput('');
    setGeneratedOtp(null);
    onUnlockAdmin();
    onToast('Mobile OTP Verified! Welcome to Admin Control Center.');
  };

  const downloadCsv = (filename: string, headers: string[], rows: Array<Array<string | number>>) => {
    const csv = buildCsvContent(headers, rows);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onToast(`${filename} downloaded.`);
  };

  const handleExportPayments = () => {
    downloadCsv(
      'STudy_STation_Payment_Report.csv',
      ['Payment ID', 'Order ID', 'Student', 'Mobile', 'Seat', 'Method', 'Amount', 'Status', 'Timestamp'],
      state.paymentGateway.transactions.map((t) => [
        t.txnId,
        t.orderId || '',
        t.studentName,
        t.phone,
        t.seat,
        t.method,
        t.amount,
        t.status,
        t.timestamp,
      ])
    );
  };

  const handleExportStudents = () => {
    downloadCsv(
      'STudy_STation_Students.csv',
      [
        'Pass ID',
        'Name',
        'Mobile',
        'Email',
        'Course/Shift',
        'Seat',
        'Total Fee',
        'Paid',
        'Balance',
        'Expiry Date',
        'Status',
      ],
      state.members.map((m) => [
        m.id,
        m.name,
        m.phone,
        m.email || '',
        getShiftShortName(state.courses, m.shift),
        formatSeatCode(m.seatNumber),
        m.fee,
        m.paidAmount ?? m.fee,
        m.balanceDue || 0,
        m.expiryDate,
        m.paymentStatus,
      ])
    );
  };

  if (!adminOtpVerified) {
    return (
      <section className="bg-cream dark:bg-slate-950 py-10 lg:py-16 min-h-[82vh]">
        <div className="max-w-md mx-auto px-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-7 border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="text-center mb-6">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-forest-950 text-mustard-400 flex items-center justify-center mb-3">
                <Smartphone className="w-7 h-7" />
              </div>
              <p className="text-xs font-bold uppercase tracking-wider text-crimson-600 dark:text-mustard-400">
                Role-Based Admin Security
              </p>
              <h1 className="text-2xl font-extrabold text-forest-950 dark:text-white mt-1">
                Admin Mobile OTP Login
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Enter the registered Admin mobile number to receive a 6-digit verification OTP.
              </p>
            </div>

            <div className="space-y-4">
              <div>
                <label
                  htmlFor="admin-mobile-input"
                  className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1"
                >
                  Registered Admin Mobile Number
                </label>
                <div className="flex gap-2">
                  <input
                    id="admin-mobile-input"
                    type="tel"
                    maxLength={10}
                    value={mobileInput}
                    onChange={(e) => setMobileInput(e.target.value)}
                    className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono font-bold"
                  />
                  <button
                    type="button"
                    onClick={handleSendOtp}
                    className="bg-forest-900 hover:bg-forest-800 text-white font-bold text-xs px-4 py-2.5 rounded-xl whitespace-nowrap cursor-pointer"
                  >
                    Send OTP
                  </button>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5">
                  Authorized Number:{' '}
                  <strong className="font-mono text-forest-900 dark:text-mustard-400">
                    {state.adminMobile}
                  </strong>
                </p>
              </div>

              <form
                onSubmit={handleVerifyOtp}
                className="space-y-4 pt-3 border-t border-slate-100 dark:border-slate-800"
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label
                      htmlFor="admin-otp-code-input"
                      className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300"
                    >
                      Enter 6-Digit SMS OTP
                    </label>
                    {generatedOtp && (
                      <span
                        data-testid="demo-otp-helper"
                        className="text-xs font-mono font-bold bg-mustard-100 text-forest-950 px-2 py-0.5 rounded"
                      >
                        Demo OTP: {generatedOtp}
                      </span>
                    )}
                  </div>
                  <input
                    id="admin-otp-code-input"
                    type="text"
                    required
                    maxLength={6}
                    pattern="[0-9]{6}"
                    value={otpInput}
                    onChange={(e) => setOtpInput(e.target.value)}
                    placeholder="••••••"
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-center text-xl font-mono font-bold tracking-[0.35em]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-mustard-500 hover:bg-mustard-400 text-forest-950 font-bold text-sm py-3.5 rounded-xl flex items-center justify-center gap-2 cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Verify OTP & Unlock Admin</span>
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    );
  }

  const netRevenue = state.paymentGateway.transactions
    .filter((t) => t.status === 'Verified Paid')
    .reduce((sum, t) => sum + Number(t.amount || 0), 0);

  const seatCounts = getShiftSeatCounts(state, seatFilterShift);
  const vacantSeats = Array.from({ length: state.totalSeats }, (_, i) => i + 1).filter(
    (num) => getSeatStatusForShift(state, num, vacantFilterShift).status === 'available'
  );
  const fullTimers = state.members.filter(
    (m) => m.shift === 'fulltime' && m.applicationStatus !== 'Rejected'
  );
  const soonExpiring: Array<MemberRecord & { days: number }> = [];
  const pastExpired: Array<MemberRecord & { days: number }> = [];
  for (const m of state.members) {
    const d = diffDaysFromTodayIST(m.expiryDate);
    if (d < 0) pastExpired.push({ ...m, days: d });
    else if (d <= 3) soonExpiring.push({ ...m, days: d });
  }

  const filteredStudents = state.members.filter((m) => {
    const q = studentSearch.trim().toLowerCase();
    if (!q) return true;
    return (
      m.name.toLowerCase().includes(q) ||
      m.phone.includes(q) ||
      formatSeatCode(m.seatNumber).toLowerCase().includes(q) ||
      m.id.toLowerCase().includes(q)
    );
  });

  const istNow = getISTDateInfo(0);

  return (
    <section className="bg-cream dark:bg-slate-950 py-8 lg:py-12 min-h-[85vh]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {/* Top Admin Header */}
        <div className="bg-forest-950 text-white rounded-2xl p-6 border border-mustard-500/40 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-mustard-400 text-forest-950 flex items-center justify-center shrink-0">
              <Crown className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-mono text-emerald-300">
                OTP Verified Admin · +91 {state.adminMobile}
              </p>
              <h1 className="text-xl sm:text-2xl font-extrabold mt-0.5">
                {state.website.brandName} — Admin Control Center
              </h1>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleExportPayments}
              className="bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold px-3.5 py-2.5 rounded-xl flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Payment Report CSV</span>
            </button>
            <button
              type="button"
              onClick={handleExportStudents}
              className="bg-forest-800 hover:bg-forest-700 text-white text-xs font-bold px-3.5 py-2.5 rounded-xl border border-white/15 flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-mustard-400" />
              <span>Student CSV</span>
            </button>
            <button
              type="button"
              onClick={onLockAdmin}
              className="bg-crimson-600 hover:bg-crimson-500 text-white text-xs font-bold px-3.5 py-2.5 rounded-xl flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Lock Admin</span>
            </button>
          </div>
        </div>

        {/* 9 Admin Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar" role="tablist">
          {ADMIN_TABS.map((t) => {
            const active = activeTab === t.key;
            return (
              <button
                key={t.key}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setActiveTab(t.key)}
                className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  active
                    ? 'bg-forest-900 text-white dark:bg-mustard-400 dark:text-forest-950'
                    : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
                }`}
              >
                {t.label}
              </button>
            );
          })}
        </div>

        {/* TAB 1: WEBSITE & FAQs */}
        {activeTab === 'website' && (
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 space-y-6">
            <div>
              <h2 className="text-xl font-extrabold text-forest-950 dark:text-white flex items-center gap-2">
                <Globe className="w-5 h-5 text-forest-700 dark:text-mustard-400" />
                <span>Website Content, Announcements, Contact & FAQs</span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Changes reflect immediately on the public Overview page.
              </p>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                onUpdateState(
                  (prev) => ({
                    ...prev,
                    website: {
                      ...prev.website,
                      brandName: brandName.trim(),
                      tagline: tagline.trim(),
                      announcement: announcement.trim(),
                      hoursBadge: hoursBadge.trim(),
                      phone: phone.trim(),
                      address: address.trim(),
                    },
                  }),
                  'Updated Website Content, Banners & Contact Settings'
                );
                onToast('Website settings published live!');
              }}
              className="space-y-5"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-cream dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700">
                <div>
                  <label
                    htmlFor="wc-brand"
                    className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1"
                  >
                    Brand Name
                  </label>
                  <input
                    id="wc-brand"
                    type="text"
                    required
                    value={brandName}
                    onChange={(e) => setBrandName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm font-bold"
                  />
                </div>
                <div>
                  <label
                    htmlFor="wc-tagline"
                    className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1"
                  >
                    Tagline
                  </label>
                  <input
                    id="wc-tagline"
                    type="text"
                    required
                    value={tagline}
                    onChange={(e) => setTagline(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm font-bold"
                  />
                </div>
                <div className="md:col-span-2">
                  <label
                    htmlFor="wc-announcement"
                    className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1"
                  >
                    Top Announcement Banner
                  </label>
                  <input
                    id="wc-announcement"
                    type="text"
                    required
                    value={announcement}
                    onChange={(e) => setAnnouncement(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm font-medium"
                  />
                </div>
                <div>
                  <label
                    htmlFor="wc-hours"
                    className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1"
                  >
                    Opening Hours Badge
                  </label>
                  <input
                    id="wc-hours"
                    type="text"
                    required
                    value={hoursBadge}
                    onChange={(e) => setHoursBadge(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm font-bold"
                  />
                </div>
                <div>
                  <label
                    htmlFor="wc-phone"
                    className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1"
                  >
                    Contact & WhatsApp Number
                  </label>
                  <input
                    id="wc-phone"
                    type="tel"
                    required
                    pattern="[0-9]{10}"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm font-mono font-bold"
                  />
                </div>
                <div className="md:col-span-2">
                  <label
                    htmlFor="wc-address"
                    className="block text-xs font-bold uppercase text-slate-600 dark:text-slate-300 mb-1"
                  >
                    Campus Address
                  </label>
                  <input
                    id="wc-address"
                    type="text"
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-sm font-medium"
                  />
                </div>
              </div>

              {/* FAQs Editor */}
              <div className="bg-forest-50 dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
                <h3 className="text-xs font-extrabold uppercase text-forest-900 dark:text-mustard-400">
                  Manage Visitor FAQs
                </h3>
                <div className="space-y-2">
                  {state.website.faqs.map((f, idx) => (
                    <div
                      key={idx}
                      className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3 text-xs"
                    >
                      <div>
                        <p className="font-bold text-forest-950 dark:text-white">{f.q}</p>
                        <p className="text-slate-500 dark:text-slate-400 mt-0.5">{f.a}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          onUpdateState((prev) => ({
                            ...prev,
                            website: {
                              ...prev.website,
                              faqs: prev.website.faqs.filter((_, i) => i !== idx),
                            },
                          }));
                          onToast('FAQ removed.');
                        }}
                        className="text-crimson-600 font-bold hover:underline shrink-0 cursor-pointer"
                      >
                        Delete
                      </button>
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2">
                  <input
                    type="text"
                    aria-label="New FAQ Question"
                    value={newFaqQ}
                    onChange={(e) => setNewFaqQ(e.target.value)}
                    placeholder="New FAQ Question"
                    className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-bold"
                  />
                  <input
                    type="text"
                    aria-label="New FAQ Answer"
                    value={newFaqA}
                    onChange={(e) => setNewFaqA(e.target.value)}
                    placeholder="Answer"
                    className="px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!newFaqQ.trim() || !newFaqA.trim()) return;
                      onUpdateState(
                        (prev) => ({
                          ...prev,
                          website: {
                            ...prev.website,
                            faqs: [
                              ...prev.website.faqs,
                              { q: newFaqQ.trim(), a: newFaqA.trim() },
                            ],
                          },
                        }),
                        `Added FAQ: "${newFaqQ.trim()}"`
                      );
                      setNewFaqQ('');
                      setNewFaqA('');
                      onToast('FAQ added.');
                    }}
                    className="bg-forest-900 text-white text-xs font-bold py-2 px-4 rounded-xl cursor-pointer"
                  >
                    + Add FAQ
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-4">
                <button
                  type="submit"
                  className="bg-forest-900 hover:bg-forest-800 text-white font-bold text-xs px-6 py-3.5 rounded-xl flex items-center gap-2 cursor-pointer"
                >
                  <Save className="w-4 h-4 text-mustard-400" />
                  <span>Save & Publish Website Settings</span>
                </button>
                <button
                  type="button"
                  onClick={onResetDefaults}
                  className="text-xs font-bold text-crimson-600 hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset All Data to Defaults</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* TAB 2: PAYMENT GATEWAY & REFUNDS */}
        {activeTab === 'payment' && (
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div>
                <h2 className="text-xl font-extrabold text-forest-950 dark:text-white flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-emerald-700 dark:text-mustard-400" />
                  <span>Payment Gateway, Partial/Full Rules & Refunds</span>
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Configure Razorpay / Cashfree mode, partial seat lock amount, and issue refunds.
                </p>
              </div>
              <div className="bg-forest-950 text-white px-4 py-3 rounded-xl text-right">
                <span className="text-[11px] uppercase text-mustard-400 block font-bold">
                  Verified Net Revenue
                </span>
                <span className="text-2xl font-mono font-bold tabular-nums text-emerald-400">
                  ₹{netRevenue.toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const allowTok = pgAllowToken;
                const allowFul = !pgAllowToken && !pgAllowFull ? true : pgAllowFull;
                setPgAllowFull(allowFul);
                onUpdateState(
                  (prev) => ({
                    ...prev,
                    paymentGateway: {
                      ...prev.paymentGateway,
                      provider: pgProvider,
                      mode: pgMode,
                      keyId: pgKeyId.trim(),
                      upiId: pgUpiId.trim(),
                      tokenAmount: Number(pgTokenAmount),
                      balanceDeadlineDays: Number(pgBalanceDays),
                      lockDurationMins: Number(pgLockMins),
                      merchantName: pgMerchantName.trim(),
                      allowTokenBooking: allowTok,
                      allowFullPayment: allowFul,
                      enableUpi: pgEnableUpi,
                      enableCard: pgEnableCard,
                      enableNetbanking: pgEnableNet,
                      enableWallets: pgEnableWallet,
                    },
                  }),
                  `Updated Payment Gateway (${pgProvider} · ${pgMode})`
                );
                onToast(`${pgProvider} (${pgMode}) settings saved!`);
              }}
              className="space-y-5"
            >
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-cream dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700">
                <div>
                  <label
                    htmlFor="pg-provider"
                    className="block text-[11px] font-bold uppercase text-slate-600 dark:text-slate-300 mb-1"
                  >
                    Gateway Provider
                  </label>
                  <select
                    id="pg-provider"
                    value={pgProvider}
                    onChange={(e) => setPgProvider(e.target.value as 'Razorpay' | 'Cashfree')}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-bold"
                  >
                    <option value="Razorpay">Razorpay</option>
                    <option value="Cashfree">Cashfree Payments</option>
                  </select>
                </div>
                <div>
                  <label
                    htmlFor="pg-mode"
                    className="block text-[11px] font-bold uppercase text-slate-600 dark:text-slate-300 mb-1"
                  >
                    Gateway Mode
                  </label>
                  <select
                    id="pg-mode"
                    value={pgMode}
                    onChange={(e) => setPgMode(e.target.value as 'SANDBOX' | 'LIVE')}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-bold"
                  >
                    <option value="SANDBOX">Sandbox / Test Mode</option>
                    <option value="LIVE">Live Production Mode</option>
                  </select>
                </div>
                <div>
                  <label
                    htmlFor="pg-key"
                    className="block text-[11px] font-bold uppercase text-slate-600 dark:text-slate-300 mb-1"
                  >
                    Public Key ID
                  </label>
                  <input
                    id="pg-key"
                    type="text"
                    value={pgKeyId}
                    onChange={(e) => setPgKeyId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
                  />
                </div>
                <div>
                  <label
                    htmlFor="pg-upi"
                    className="block text-[11px] font-bold uppercase text-slate-600 dark:text-slate-300 mb-1"
                  >
                    Merchant UPI ID
                  </label>
                  <input
                    id="pg-upi"
                    type="text"
                    required
                    value={pgUpiId}
                    onChange={(e) => setPgUpiId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
                  />
                </div>
                <div>
                  <label
                    htmlFor="pg-token"
                    className="block text-[11px] font-bold uppercase text-crimson-600 dark:text-amber-400 mb-1"
                  >
                    Partial Lock Fee (₹)
                  </label>
                  <input
                    id="pg-token"
                    type="number"
                    min={1}
                    required
                    value={pgTokenAmount}
                    onChange={(e) => setPgTokenAmount(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
                  />
                </div>
                <div>
                  <label
                    htmlFor="pg-days"
                    className="block text-[11px] font-bold uppercase text-slate-600 dark:text-slate-300 mb-1"
                  >
                    Balance Deadline (Days)
                  </label>
                  <input
                    id="pg-days"
                    type="number"
                    min={1}
                    max={30}
                    required
                    value={pgBalanceDays}
                    onChange={(e) => setPgBalanceDays(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
                  />
                </div>
                <div>
                  <label
                    htmlFor="pg-lock-mins"
                    className="block text-[11px] font-bold uppercase text-slate-600 dark:text-slate-300 mb-1"
                  >
                    Temp Lock Timer (Mins)
                  </label>
                  <input
                    id="pg-lock-mins"
                    type="number"
                    min={2}
                    max={60}
                    required
                    value={pgLockMins}
                    onChange={(e) => setPgLockMins(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
                  />
                </div>
                <div>
                  <label
                    htmlFor="pg-merchant"
                    className="block text-[11px] font-bold uppercase text-slate-600 dark:text-slate-300 mb-1"
                  >
                    Merchant Name
                  </label>
                  <input
                    id="pg-merchant"
                    type="text"
                    required
                    value={pgMerchantName}
                    onChange={(e) => setPgMerchantName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 bg-forest-50 dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
                {[
                  { label: 'Partial Lock', checked: pgAllowToken, onChange: setPgAllowToken },
                  { label: 'Full Payment', checked: pgAllowFull, onChange: setPgAllowFull },
                  { label: 'UPI Apps', checked: pgEnableUpi, onChange: setPgEnableUpi },
                  { label: 'Cards', checked: pgEnableCard, onChange: setPgEnableCard },
                  { label: 'NetBanking', checked: pgEnableNet, onChange: setPgEnableNet },
                  { label: 'Wallets', checked: pgEnableWallet, onChange: setPgEnableWallet },
                ].map((toggle) => (
                  <label
                    key={toggle.label}
                    className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs font-bold cursor-pointer"
                  >
                    <span>{toggle.label}</span>
                    <input
                      type="checkbox"
                      checked={toggle.checked}
                      onChange={(e) => toggle.onChange(e.target.checked)}
                      className="w-4 h-4 accent-forest-900"
                    />
                  </label>
                ))}
              </div>

              <button
                type="submit"
                className="bg-forest-900 hover:bg-forest-800 text-white font-bold text-xs px-6 py-3.5 rounded-xl flex items-center gap-2 cursor-pointer"
              >
                <Save className="w-4 h-4 text-mustard-400" />
                <span>Save Gateway Configuration</span>
              </button>
            </form>

            {/* Transactions Table */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-xs font-extrabold uppercase text-forest-900 dark:text-mustard-400">
                  Verified Gateway Transactions & Refunds
                </h3>
                <button
                  type="button"
                  onClick={handleExportPayments}
                  className="text-xs font-bold text-emerald-700 dark:text-emerald-400 hover:underline cursor-pointer"
                >
                  Download Payment Report
                </button>
              </div>
              <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl max-h-72 overflow-y-auto">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-slate-50 dark:bg-slate-800 text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400 sticky top-0">
                    <tr>
                      <th className="py-3 px-3">Payment / Order ID</th>
                      <th className="py-3 px-3">Student</th>
                      <th className="py-3 px-3">Method & Signature</th>
                      <th className="py-3 px-3">Amount</th>
                      <th className="py-3 px-3">Status</th>
                      <th className="py-3 px-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                    {state.paymentGateway.transactions.map((t) => {
                      const isRefunded = t.status === 'Refunded';
                      return (
                        <tr key={t.txnId}>
                          <td className="py-3 px-3">
                            <p className="font-mono font-bold text-forest-900 dark:text-mustard-400">
                              {t.txnId}
                            </p>
                            <p className="text-[11px] font-mono text-slate-400">{t.orderId}</p>
                          </td>
                          <td className="py-3 px-3">
                            <p className="font-bold">{t.studentName}</p>
                            <p className="text-[11px] font-mono text-slate-500">
                              {t.seat} · {t.phone}
                            </p>
                          </td>
                          <td className="py-3 px-3">
                            <p className="font-semibold">{t.method}</p>
                            <p className="text-[11px] font-mono text-emerald-700 dark:text-emerald-400">
                              {t.signature}
                            </p>
                          </td>
                          <td
                            className={`py-3 px-3 font-mono font-bold tabular-nums ${
                              isRefunded ? 'text-slate-400 line-through' : 'text-emerald-700 dark:text-emerald-400'
                            }`}
                          >
                            ₹{t.amount}
                          </td>
                          <td className="py-3 px-3">
                            <span
                              className={`font-bold ${
                                isRefunded ? 'text-slate-500' : 'text-emerald-700 dark:text-emerald-400'
                              }`}
                            >
                              {t.status}
                            </span>
                            <span className="block text-[11px] font-mono text-slate-400">
                              {t.timestamp}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-right">
                            {isRefunded ? (
                              <span className="text-[11px] text-slate-400">Refunded</span>
                            ) : (
                              <button
                                type="button"
                                onClick={() => {
                                  onUpdateState(
                                    (prev) => ({
                                      ...prev,
                                      paymentGateway: {
                                        ...prev.paymentGateway,
                                        transactions: prev.paymentGateway.transactions.map((x) =>
                                          x.txnId === t.txnId ? { ...x, status: 'Refunded' } : x
                                        ),
                                      },
                                    }),
                                    `Issued refund of ₹${t.amount} for ${t.txnId}`
                                  );
                                  onToast(`Refund of ₹${t.amount} initiated!`);
                                }}
                                className="px-2.5 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/50 hover:bg-crimson-600 text-crimson-600 hover:text-white font-bold text-[11px] cursor-pointer"
                              >
                                Issue Refund
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: COURSES & SEAT MANAGER */}
        {activeTab === 'seats' && (
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 space-y-6">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div>
                <h2 className="text-xl font-extrabold text-forest-950 dark:text-white">
                  Courses, Fees & Seat Capacity Manager
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Add courses, adjust fees, scale seat capacity, or tap seats to Block/Unblock.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <select
                  aria-label="Filter seats by shift"
                  value={seatFilterShift}
                  onChange={(e) => setSeatFilterShift(e.target.value)}
                  className="px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-forest-50 dark:bg-slate-800 text-xs font-bold"
                >
                  {state.courses.map((c) => (
                    <option key={c.key} value={c.key}>
                      {c.name}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => {
                    onUpdateState(
                      (prev) => ({ ...prev, totalSeats: prev.totalSeats + 1 }),
                      `Increased capacity to ${state.totalSeats + 1} seats`
                    );
                    onToast(`Total capacity is now ${state.totalSeats + 1} seats.`);
                  }}
                  className="bg-forest-900 hover:bg-forest-800 text-white text-xs font-bold px-3.5 py-2 rounded-xl cursor-pointer"
                >
                  +1 Seat
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onUpdateState(
                      (prev) => ({ ...prev, totalSeats: prev.totalSeats + 5 }),
                      `Increased capacity by +5 to ${state.totalSeats + 5} seats`
                    );
                    onToast(`Total capacity is now ${state.totalSeats + 5} seats.`);
                  }}
                  className="bg-forest-700 hover:bg-forest-600 text-white text-xs font-bold px-3.5 py-2 rounded-xl cursor-pointer"
                >
                  +5 Seats
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (state.totalSeats <= 50) {
                      onToast('Minimum 50 seats required.');
                      return;
                    }
                    const lastSeat = state.totalSeats;
                    if (state.members.some((m) => m.seatNumber === lastSeat)) {
                      onToast(`Seat ${formatSeatCode(lastSeat)} is currently occupied.`);
                      return;
                    }
                    onUpdateState(
                      (prev) => ({
                        ...prev,
                        totalSeats: prev.totalSeats - 1,
                        blockedSeats: prev.blockedSeats.filter((s) => s <= prev.totalSeats - 1),
                      }),
                      `Removed seat ${formatSeatCode(lastSeat)}`
                    );
                    onToast(`Removed ${formatSeatCode(lastSeat)}.`);
                  }}
                  className="bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 text-slate-800 dark:text-slate-200 text-xs font-bold px-3.5 py-2 rounded-xl cursor-pointer"
                >
                  -1 Seat
                </button>
              </div>
            </div>

            {/* Add Course Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const key = `course_${Date.now()}`;
                onUpdateState(
                  (prev) => ({
                    ...prev,
                    courses: [
                      ...prev.courses,
                      {
                        key,
                        name: newCourseName.trim(),
                        schedule: newCourseTime.trim(),
                        fee: Number(newCourseFee),
                        badge: 'Custom Plan',
                        icon: 'book-open',
                      },
                    ],
                  }),
                  `Added course ${newCourseName.trim()} (₹${newCourseFee}/mo)`
                );
                setNewCourseName('');
                setNewCourseTime('');
                setNewCourseFee('');
                onToast('Added new course plan.');
              }}
              className="bg-forest-50 dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 grid grid-cols-1 sm:grid-cols-4 gap-3 items-end"
            >
              <div>
                <label
                  htmlFor="new-course-name"
                  className="block text-[11px] font-bold uppercase mb-1"
                >
                  Course / Shift Name *
                </label>
                <input
                  id="new-course-name"
                  type="text"
                  required
                  value={newCourseName}
                  onChange={(e) => setNewCourseName(e.target.value)}
                  placeholder="e.g. Foundation Batch"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-bold"
                />
              </div>
              <div>
                <label
                  htmlFor="new-course-time"
                  className="block text-[11px] font-bold uppercase mb-1"
                >
                  Timings *
                </label>
                <input
                  id="new-course-time"
                  type="text"
                  required
                  value={newCourseTime}
                  onChange={(e) => setNewCourseTime(e.target.value)}
                  placeholder="e.g. 9:00 AM – 5:00 PM"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-bold"
                />
              </div>
              <div>
                <label
                  htmlFor="new-course-fee"
                  className="block text-[11px] font-bold uppercase mb-1"
                >
                  Monthly Fee (₹) *
                </label>
                <input
                  id="new-course-fee"
                  type="number"
                  required
                  min={99}
                  value={newCourseFee}
                  onChange={(e) => setNewCourseFee(e.target.value)}
                  placeholder="799"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
                />
              </div>
              <button
                type="submit"
                className="bg-forest-900 text-white font-bold text-xs py-2.5 px-4 rounded-xl flex items-center justify-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 text-mustard-400" />
                <span>Add Course / Plan</span>
              </button>
            </form>

            {/* Courses Fee Quick Editor */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {state.courses.map((c, idx) => (
                <div
                  key={c.key}
                  className="bg-cream dark:bg-slate-800 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold">{c.name}</span>
                    {idx >= 4 ? (
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateState((prev) => ({
                            ...prev,
                            courses: prev.courses.filter((x) => x.key !== c.key),
                          }))
                        }
                        className="text-[11px] text-crimson-600 font-bold cursor-pointer"
                      >
                        Remove
                      </button>
                    ) : (
                      <span className="text-[11px] text-slate-400">Core</span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">{c.schedule}</p>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold">₹</span>
                    <input
                      type="number"
                      aria-label={`${c.name} monthly fee`}
                      value={c.fee}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        if (val > 0) {
                          onUpdateState((prev) => ({
                            ...prev,
                            courses: prev.courses.map((x) =>
                              x.key === c.key ? { ...x, fee: val } : x
                            ),
                          }));
                        }
                      }}
                      className="w-24 px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
                    />
                    <span className="text-[11px] text-slate-400">/mo</span>
                  </div>
                </div>
              ))}
            </div>

            {/* 4 Seat Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-cream dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 text-center">
                <p data-testid="admin-sm-total" className="text-2xl font-mono font-bold tabular-nums">
                  {seatCounts.total}
                </p>
                <p className="text-[11px] font-bold uppercase text-slate-500">Total Seats</p>
              </div>
              <div className="bg-emerald-50 dark:bg-emerald-950/30 p-4 rounded-xl border border-emerald-200 dark:border-emerald-900 text-center">
                <p className="text-2xl font-mono font-bold tabular-nums text-emerald-700 dark:text-emerald-400">
                  {seatCounts.available}
                </p>
                <p className="text-[11px] font-bold uppercase text-emerald-800 dark:text-emerald-300">
                  Available
                </p>
              </div>
              <div className="bg-rose-50 dark:bg-rose-950/30 p-4 rounded-xl border border-rose-200 dark:border-rose-900 text-center">
                <p className="text-2xl font-mono font-bold tabular-nums text-crimson-600 dark:text-rose-400">
                  {seatCounts.reserved}
                </p>
                <p className="text-[11px] font-bold uppercase text-crimson-700 dark:text-rose-300">
                  Reserved
                </p>
              </div>
              <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-xl border border-slate-300 dark:border-slate-700 text-center">
                <p className="text-2xl font-mono font-bold tabular-nums">{seatCounts.blocked}</p>
                <p className="text-[11px] font-bold uppercase text-slate-500">Blocked</p>
              </div>
            </div>

            {/* Admin Seat Grid */}
            <div className="grid grid-cols-5 sm:grid-cols-8 md:grid-cols-10 gap-2">
              {Array.from({ length: state.totalSeats }, (_, idx) => idx + 1).map((num) => {
                const code = formatSeatCode(num);
                const info = getSeatStatusForShift(state, num, seatFilterShift);
                if (info.status === 'blocked') {
                  return (
                    <button
                      key={num}
                      type="button"
                      onClick={() => {
                        onUpdateState(
                          (prev) => ({
                            ...prev,
                            blockedSeats: prev.blockedSeats.filter((s) => s !== num),
                          }),
                          `Unblocked seat ${code}`
                        );
                        onToast(`Seat ${code} unblocked.`);
                      }}
                      className="py-2.5 px-1 rounded-xl bg-slate-800 text-mustard-400 text-[11px] font-mono font-bold flex flex-col items-center cursor-pointer"
                    >
                      <Ban className="w-3 h-3 mb-0.5" />
                      <span>{code}</span>
                    </button>
                  );
                }
                if (info.status === 'reserved') {
                  return (
                    <button
                      key={num}
                      type="button"
                      onClick={() => onToast(`${code} reserved by ${info.occupant?.name}`)}
                      className="py-2.5 px-1 rounded-xl bg-crimson-600 text-white text-[11px] font-mono font-bold flex flex-col items-center cursor-pointer"
                    >
                      <Check className="w-3 h-3 mb-0.5" />
                      <span>{code}</span>
                    </button>
                  );
                }
                return (
                  <button
                    key={num}
                    type="button"
                    onClick={() => {
                      onUpdateState(
                        (prev) => ({
                          ...prev,
                          blockedSeats: [...prev.blockedSeats, num],
                        }),
                        `Blocked seat ${code}`
                      );
                      onToast(`Seat ${code} blocked.`);
                    }}
                    className="py-2.5 px-1 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 hover:bg-amber-100 border border-emerald-500/40 text-forest-900 dark:text-emerald-200 text-[11px] font-mono font-bold flex flex-col items-center cursor-pointer"
                  >
                    <Check className="w-3 h-3 mb-0.5 opacity-70" />
                    <span>{code}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 4: VACANT SEATS TRACKER */}
        {activeTab === 'available' && (
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div>
                <h2 className="text-xl font-extrabold text-forest-950 dark:text-white">
                  Available (Vacant) Seats Tracker
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Currently unbooked and unblocked cabins ready for immediate walk-in allotment.
                </p>
              </div>
              <select
                aria-label="Select shift for vacant seats"
                value={vacantFilterShift}
                onChange={(e) => setVacantFilterShift(e.target.value)}
                className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-forest-50 dark:bg-slate-800 text-xs font-bold"
              >
                {state.courses.map((c) => (
                  <option key={c.key} value={c.key}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900 rounded-xl p-4 flex items-center justify-between text-xs font-bold">
              <span>Vacant Seats Ready for Admission:</span>
              <span className="font-mono text-sm text-emerald-700 dark:text-emerald-400">
                {vacantSeats.length} Vacant
              </span>
            </div>

            <div className="grid grid-cols-4 sm:grid-cols-8 md:grid-cols-10 gap-2.5">
              {vacantSeats.map((num) => (
                <div
                  key={num}
                  className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-500/40 rounded-xl p-3 text-center"
                >
                  <span className="font-mono font-bold text-forest-950 dark:text-emerald-200 text-sm block">
                    {formatSeatCode(num)}
                  </span>
                  <span className="text-[10px] font-bold uppercase text-emerald-700 dark:text-emerald-400">
                    Vacant
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: FULL-TIME MEMBERS */}
        {activeTab === 'fulltime' && (
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div>
                <h2 className="text-xl font-extrabold text-forest-950 dark:text-white">
                  Reserved Full-Time Members (₹{getShiftPrice(state.courses, 'fulltime')} / Month)
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Dedicated 24-hour cabin holders locked across all shifts.
                </p>
              </div>
              <span className="text-xs font-mono font-bold text-forest-900 dark:text-mustard-400">
                {fullTimers.length} Full-Time Members
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold uppercase text-slate-400">
                    <th className="py-3 px-3">Seat</th>
                    <th className="py-3 px-3">Student & Mobile</th>
                    <th className="py-3 px-3">Plan Fee</th>
                    <th className="py-3 px-3">Status</th>
                    <th className="py-3 px-3">Expiry (IST)</th>
                    <th className="py-3 px-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                  {fullTimers.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-400">
                        No Full-Time Reserved members enrolled yet.
                      </td>
                    </tr>
                  ) : (
                    fullTimers.map((m) => {
                      const d = diffDaysFromTodayIST(m.expiryDate);
                      return (
                        <tr key={m.id}>
                          <td className="py-3 px-3 font-mono font-bold">
                            {formatSeatCode(m.seatNumber)}
                          </td>
                          <td className="py-3 px-3">
                            <p className="font-bold">{m.name}</p>
                            <p className="text-[11px] font-mono text-slate-500">
                              {m.phone} · #{m.id}
                            </p>
                          </td>
                          <td className="py-3 px-3 font-mono font-bold">₹{m.fee}/mo</td>
                          <td className="py-3 px-3 font-bold">
                            {d < 0 ? (
                              <span className="text-crimson-600">Expired</span>
                            ) : (
                              <span className="text-emerald-700 dark:text-emerald-400">
                                Active ({d}d)
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-3 font-mono">{m.expiryDate}</td>
                          <td className="py-3 px-3 text-right">
                            <button
                              type="button"
                              onClick={() => onRenewMember(m.id)}
                              className="bg-mustard-400 text-forest-950 font-bold px-3 py-1.5 rounded-lg text-[11px] cursor-pointer"
                            >
                              +30d Renew
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 6: MEMBERSHIP EXPIRY */}
        {activeTab === 'expiry' && (
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 space-y-6">
            <div>
              <h2 className="text-xl font-extrabold text-forest-950 dark:text-white flex items-center gap-2">
                <Hourglass className="w-5 h-5 text-crimson-600 dark:text-amber-400" />
                <span>Membership Expiry & Renewal Deadlines</span>
              </h2>
            </div>

            <div>
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-amber-700 dark:text-amber-400 mb-3">
                Expiring Soon (Next 3 Days)
              </h3>
              <div className="overflow-x-auto border border-amber-200 dark:border-amber-900/50 rounded-xl">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-amber-50 dark:bg-amber-950/30 text-[11px] font-bold uppercase text-amber-900 dark:text-amber-300">
                    <tr>
                      <th className="py-3 px-4">Student & Mobile</th>
                      <th className="py-3 px-4">Seat & Shift</th>
                      <th className="py-3 px-4">Expiry Date</th>
                      <th className="py-3 px-4 text-right">Renew</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-amber-100 dark:divide-slate-800 text-xs">
                    {soonExpiring.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-6 text-center text-slate-400">
                          No memberships expiring in the next 3 days.
                        </td>
                      </tr>
                    ) : (
                      soonExpiring.map((m) => (
                        <tr key={m.id}>
                          <td className="py-3 px-4">
                            <p className="font-bold">{m.name}</p>
                            <p className="text-[11px] font-mono text-slate-500">{m.phone}</p>
                          </td>
                          <td className="py-3 px-4">
                            <span className="font-mono font-bold">
                              {formatSeatCode(m.seatNumber)}
                            </span>{' '}
                            · {getShiftShortName(state.courses, m.shift)}
                          </td>
                          <td className="py-3 px-4 font-mono font-bold text-amber-700 dark:text-amber-400">
                            {m.expiryDate} ({m.days}d left)
                          </td>
                          <td className="py-3 px-4 text-right">
                            <button
                              type="button"
                              onClick={() => onRenewMember(m.id)}
                              className="bg-forest-900 text-white font-bold px-3 py-1.5 rounded-lg text-[11px] cursor-pointer"
                            >
                              Renew (+30d)
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div>
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-crimson-600 dark:text-rose-400 mb-3">
                Already Expired Memberships
              </h3>
              <div className="overflow-x-auto border border-rose-200 dark:border-rose-900/50 rounded-xl">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-rose-50 dark:bg-rose-950/30 text-[11px] font-bold uppercase text-crimson-700 dark:text-rose-300">
                    <tr>
                      <th className="py-3 px-4">Student & Mobile</th>
                      <th className="py-3 px-4">Seat & Shift</th>
                      <th className="py-3 px-4">Expired On</th>
                      <th className="py-3 px-4 text-right">Renew</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                    {pastExpired.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-6 text-center text-slate-400">
                          No expired memberships.
                        </td>
                      </tr>
                    ) : (
                      pastExpired.map((m) => (
                        <tr key={m.id}>
                          <td className="py-3 px-4">
                            <p className="font-bold">{m.name}</p>
                            <p className="text-[11px] font-mono text-slate-500">{m.phone}</p>
                          </td>
                          <td className="py-3 px-4">
                            <span className="font-mono font-bold">
                              {formatSeatCode(m.seatNumber)}
                            </span>{' '}
                            · {getShiftShortName(state.courses, m.shift)}
                          </td>
                          <td className="py-3 px-4 font-mono font-bold text-crimson-600 dark:text-rose-400">
                            {m.expiryDate} ({Math.abs(m.days)}d overdue)
                          </td>
                          <td className="py-3 px-4 text-right">
                            <button
                              type="button"
                              onClick={() => onRenewMember(m.id)}
                              className="bg-crimson-600 text-white font-bold px-3 py-1.5 rounded-lg text-[11px] cursor-pointer"
                            >
                              Renew (+30d)
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: STUDENTS, APPROVALS & 2-DAY IST REMINDERS */}
        {activeTab === 'reminders' && (
          <div className="space-y-6">
            {/* Automatic 2-Day IST Reminder Engine */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 space-y-5">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-forest-700 dark:text-mustard-400">
                    India Standard Time (IST) Automated Scheduler
                  </p>
                  <h2 className="text-xl font-extrabold text-forest-950 dark:text-white mt-0.5">
                    Automatic 2-Day Expiry Reminders (SMS & WhatsApp)
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Dispatches 1 SMS & 1 WhatsApp reminder 2 days prior to expiry, strictly
                    deduplicated per cycle per channel.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() =>
                    onUpdateState(
                      (prev) => ({
                        ...prev,
                        reminders: {
                          ...prev.reminders,
                          livePaidServiceApproved: !prev.reminders.livePaidServiceApproved,
                        },
                      }),
                      `Toggled Live Paid SMS/WhatsApp Approval: ${!state.reminders.livePaidServiceApproved}`
                    )
                  }
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold cursor-pointer whitespace-nowrap ${
                    state.reminders.livePaidServiceApproved
                      ? 'bg-emerald-600 text-white'
                      : 'bg-amber-500 text-white'
                  }`}
                >
                  {state.reminders.livePaidServiceApproved
                    ? 'Live Paid Gateway: Approved'
                    : 'Sandbox Mode (Approve Live)'}
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <label className="bg-cream dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between cursor-pointer">
                  <div>
                    <p className="text-xs font-bold">SMS Channel</p>
                    <p className="text-[11px] text-slate-500">1 SMS per cycle (2 days prior)</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={state.reminders.smsEnabled}
                    onChange={(e) =>
                      onUpdateState((prev) => ({
                        ...prev,
                        reminders: { ...prev.reminders, smsEnabled: e.target.checked },
                      }))
                    }
                    className="w-5 h-5 accent-forest-900"
                  />
                </label>

                <label className="bg-cream dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between cursor-pointer">
                  <div>
                    <p className="text-xs font-bold">WhatsApp Channel</p>
                    <p className="text-[11px] text-slate-500">1 WhatsApp per cycle (2 days prior)</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={state.reminders.whatsappEnabled}
                    onChange={(e) =>
                      onUpdateState((prev) => ({
                        ...prev,
                        reminders: { ...prev.reminders, whatsappEnabled: e.target.checked },
                      }))
                    }
                    className="w-5 h-5 accent-forest-900"
                  />
                </label>

                <div className="bg-forest-50 dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-2">
                  <div>
                    <p className="text-xs font-bold">IST Scheduler Check</p>
                    <p className="text-[11px] font-mono text-slate-500">
                      {istNow.dateStr} · {istNow.timeStr}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={onRunReminders}
                    className="bg-forest-900 hover:bg-forest-800 text-white text-xs font-bold px-3.5 py-2.5 rounded-xl flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                  >
                    <Play className="w-3.5 h-3.5 text-mustard-400" />
                    <span>Run Check</span>
                  </button>
                </div>
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  onUpdateState((prev) => ({
                    ...prev,
                    reminders: {
                      ...prev.reminders,
                      smsTemplate: smsTemplate.trim(),
                      whatsappTemplate: waTemplate.trim(),
                    },
                  }));
                  onToast('Reminder templates saved.');
                }}
                className="grid grid-cols-1 md:grid-cols-2 gap-4"
              >
                <div>
                  <label
                    htmlFor="sms-tpl"
                    className="block text-[11px] font-bold uppercase text-slate-500 mb-1"
                  >
                    SMS Template
                  </label>
                  <textarea
                    id="sms-tpl"
                    rows={2}
                    value={smsTemplate}
                    onChange={(e) => setSmsTemplate(e.target.value)}
                    className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-cream dark:bg-slate-800 text-xs"
                  />
                </div>
                <div>
                  <label
                    htmlFor="wa-tpl"
                    className="block text-[11px] font-bold uppercase text-slate-500 mb-1"
                  >
                    WhatsApp Template
                  </label>
                  <textarea
                    id="wa-tpl"
                    rows={2}
                    value={waTemplate}
                    onChange={(e) => setWaTemplate(e.target.value)}
                    className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-cream dark:bg-slate-800 text-xs"
                  />
                </div>
                <div className="md:col-span-2 flex justify-end">
                  <button
                    type="submit"
                    className="bg-forest-900 text-white text-xs font-bold px-5 py-2.5 rounded-xl cursor-pointer"
                  >
                    Save Templates
                  </button>
                </div>
              </form>

              <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl max-h-48 overflow-y-auto">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-slate-50 dark:bg-slate-800 text-[11px] font-bold uppercase text-slate-500 sticky top-0">
                    <tr>
                      <th className="py-2.5 px-3">Student & Mobile</th>
                      <th className="py-2.5 px-3">Cycle ID</th>
                      <th className="py-2.5 px-3">Channel</th>
                      <th className="py-2.5 px-3">Delivery Status</th>
                      <th className="py-2.5 px-3">IST Timestamp</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                    {state.reminders.logs.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="py-5 text-center text-slate-400">
                          No reminders dispatched yet. Click &quot;Run Check&quot; to evaluate IST
                          2-day reminders.
                        </td>
                      </tr>
                    ) : (
                      state.reminders.logs.map((log, i) => (
                        <tr key={i}>
                          <td className="py-2.5 px-3 font-bold">
                            {log.studentName} ({log.phone})
                          </td>
                          <td className="py-2.5 px-3 font-mono text-[11px]">{log.cycleId}</td>
                          <td className="py-2.5 px-3 font-bold">{log.channel}</td>
                          <td className="py-2.5 px-3 text-emerald-700 dark:text-emerald-400 font-semibold">
                            {log.status}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-[11px]">{log.timestamp}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Students Ledger + Walk-in Admission */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <h2 className="text-xl font-extrabold text-forest-950 dark:text-white flex items-center gap-2">
                    <Users className="w-5 h-5 text-forest-700 dark:text-mustard-400" />
                    <span>Students, Approvals & Payments Ledger</span>
                  </h2>
                </div>
                <input
                  type="text"
                  aria-label="Search students"
                  value={studentSearch}
                  onChange={(e) => setStudentSearch(e.target.value)}
                  placeholder="Search student, seat, mobile..."
                  className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold w-full sm:w-64"
                />
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const seatNum = parseInt(
                    walkinSeat.trim().toUpperCase().replace('S-', ''),
                    10
                  );
                  if (isNaN(seatNum) || seatNum < 1 || seatNum > state.totalSeats) {
                    onToast(`Seat number must be between 1 and ${state.totalSeats}.`);
                    return;
                  }
                  if (getSeatStatusForShift(state, seatNum, walkinShift).status !== 'available') {
                    onToast(`Seat ${formatSeatCode(seatNum)} is not available in that shift.`);
                    return;
                  }
                  const fee = getShiftPrice(state.courses, walkinShift);
                  const newMember: MemberRecord = {
                    id: 'SS-' + Math.floor(1006 + Math.random() * 8990),
                    name: walkinName.trim(),
                    phone: walkinPhone.trim(),
                    email: '',
                    exam: 'Walk-In Admission',
                    shift: walkinShift,
                    seatNumber: seatNum,
                    fee,
                    paidAmount: fee,
                    balanceDue: 0,
                    applicationStatus: 'Approved',
                    joinedDate: getISTDateInfo(0).dateStr,
                    expiryDate: walkinExpiry,
                    cycleId: `CYC-${walkinExpiry}`,
                    paymentStatus: 'Paid',
                    notifications: [
                      `Walk-in admission verified for ${formatSeatCode(seatNum)}.`,
                    ],
                  };
                  onUpdateState(
                    (prev) => ({
                      ...prev,
                      members: [newMember, ...prev.members],
                    }),
                    `Added walk-in student ${newMember.name} to ${formatSeatCode(seatNum)}`
                  );
                  setWalkinName('');
                  setWalkinPhone('');
                  setWalkinSeat('');
                  onToast(`Walk-in student assigned to ${formatSeatCode(seatNum)}!`);
                }}
                className="bg-forest-50 dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 items-end"
              >
                <div>
                  <label htmlFor="walkin-name" className="block text-[11px] font-bold uppercase mb-1">
                    Student Name *
                  </label>
                  <input
                    id="walkin-name"
                    type="text"
                    required
                    value={walkinName}
                    onChange={(e) => setWalkinName(e.target.value)}
                    placeholder="Full Name"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-bold"
                  />
                </div>
                <div>
                  <label htmlFor="walkin-phone" className="block text-[11px] font-bold uppercase mb-1">
                    Mobile *
                  </label>
                  <input
                    id="walkin-phone"
                    type="tel"
                    required
                    pattern="[0-9]{10}"
                    maxLength={10}
                    value={walkinPhone}
                    onChange={(e) => setWalkinPhone(e.target.value)}
                    placeholder="98XXXXXXXX"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
                  />
                </div>
                <div>
                  <label htmlFor="walkin-shift" className="block text-[11px] font-bold uppercase mb-1">
                    Shift / Course *
                  </label>
                  <select
                    id="walkin-shift"
                    value={walkinShift}
                    onChange={(e) => setWalkinShift(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-bold"
                  >
                    {state.courses.map((c) => (
                      <option key={c.key} value={c.key}>
                        {c.name} (₹{c.fee})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="walkin-seat" className="block text-[11px] font-bold uppercase mb-1">
                    Seat No *
                  </label>
                  <input
                    id="walkin-seat"
                    type="text"
                    required
                    value={walkinSeat}
                    onChange={(e) => setWalkinSeat(e.target.value)}
                    placeholder="e.g. 15"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
                  />
                </div>
                <div>
                  <label htmlFor="walkin-exp" className="block text-[11px] font-bold uppercase mb-1">
                    Expiry Date *
                  </label>
                  <input
                    id="walkin-exp"
                    type="date"
                    required
                    value={walkinExpiry}
                    onChange={(e) => setWalkinExpiry(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
                  />
                </div>
                <button
                  type="submit"
                  className="bg-forest-900 hover:bg-forest-800 text-white font-bold text-xs py-2.5 px-4 rounded-xl flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5 text-mustard-400" />
                  <span>Add Student</span>
                </button>
              </form>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold uppercase text-slate-400">
                      <th className="py-3 px-3">Pass ID</th>
                      <th className="py-3 px-3">Student & Mobile</th>
                      <th className="py-3 px-3">Seat & Course</th>
                      <th className="py-3 px-3">Application</th>
                      <th className="py-3 px-3">Payment</th>
                      <th className="py-3 px-3 text-right">Controls</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                    {filteredStudents.map((m) => (
                      <tr key={m.id}>
                        <td className="py-3 px-3 font-mono font-bold text-forest-900 dark:text-mustard-400">
                          #{m.id}
                        </td>
                        <td className="py-3 px-3">
                          <p className="font-bold">{m.name}</p>
                          <p className="text-[11px] font-mono text-slate-500">
                            {m.phone} · Exp: {m.expiryDate}
                          </p>
                        </td>
                        <td className="py-3 px-3">
                          <span className="font-mono font-bold">
                            {formatSeatCode(m.seatNumber)}
                          </span>
                          <span className="block text-[11px] text-slate-500">
                            {getShiftShortName(state.courses, m.shift)} (₹{m.fee})
                          </span>
                        </td>
                        <td className="py-3 px-3">
                          <button
                            type="button"
                            onClick={() =>
                              onUpdateState(
                                (prev) => ({
                                  ...prev,
                                  members: prev.members.map((x) =>
                                    x.id === m.id
                                      ? {
                                          ...x,
                                          applicationStatus:
                                            x.applicationStatus === 'Rejected'
                                              ? 'Approved'
                                              : 'Rejected',
                                        }
                                      : x
                                  ),
                                }),
                                `Toggled approval status for ${m.name}`
                              )
                            }
                            className={`font-bold cursor-pointer ${
                              m.applicationStatus === 'Approved'
                                ? 'text-emerald-700 dark:text-emerald-400'
                                : 'text-crimson-600 dark:text-rose-400'
                            }`}
                          >
                            {m.applicationStatus}
                          </button>
                        </td>
                        <td className="py-3 px-3">
                          <button
                            type="button"
                            onClick={() =>
                              onUpdateState((prev) => ({
                                ...prev,
                                members: prev.members.map((x) => {
                                  if (x.id !== m.id) return x;
                                  const nextPaid = x.paymentStatus !== 'Paid';
                                  return {
                                    ...x,
                                    paymentStatus: nextPaid ? 'Paid' : 'Renewal Due',
                                    balanceDue: nextPaid ? 0 : x.balanceDue,
                                    paidAmount: nextPaid ? x.fee : x.paidAmount,
                                  };
                                }),
                              }))
                            }
                            className={`font-bold cursor-pointer ${
                              m.paymentStatus === 'Paid'
                                ? 'text-emerald-700 dark:text-emerald-400'
                                : 'text-amber-700 dark:text-amber-400'
                            }`}
                          >
                            {m.paymentStatus}
                          </button>
                        </td>
                        <td className="py-3 px-3 text-right space-x-1.5 whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => onRenewMember(m.id)}
                            className="px-2.5 py-1.5 rounded-lg bg-forest-900 text-white text-[11px] font-bold cursor-pointer"
                          >
                            +30d
                          </button>
                          <button
                            type="button"
                            aria-label={`Remove ${m.name}`}
                            onClick={() => {
                              onUpdateState(
                                (prev) => ({
                                  ...prev,
                                  members: prev.members.filter((x) => x.id !== m.id),
                                }),
                                `Removed ${m.name} (#${m.id}) and released ${formatSeatCode(
                                  m.seatNumber
                                )}`
                              );
                              onToast(`Removed ${m.name}.`);
                            }}
                            className="px-2.5 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/50 hover:bg-crimson-600 text-crimson-600 hover:text-white text-[11px] cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5 inline" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 8: ANIMATIONS & AUDIT LOG */}
        {activeTab === 'animations' && (
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 space-y-6">
            <div>
              <h2 className="text-xl font-extrabold text-forest-950 dark:text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-600 dark:text-mustard-400" />
                <span>Animation Controls & Admin Security Audit Log</span>
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-cream dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-4">
                <div>
                  <h3 className="font-bold text-sm">Global Animations</h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Controls page transitions and subtle motion effects.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    onUpdateState((prev) => ({
                      ...prev,
                      animations: { ...prev.animations, enabled: !prev.animations.enabled },
                    }))
                  }
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold text-white cursor-pointer ${
                    state.animations.enabled ? 'bg-emerald-600' : 'bg-slate-700'
                  }`}
                >
                  Animations: {state.animations.enabled ? 'ON' : 'OFF'}
                </button>
              </div>

              <div className="bg-cream dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
                <div className="flex items-center justify-between">
                  <label htmlFor="anim-speed-slider" className="font-bold text-sm">
                    Animation Speed Multiplier
                  </label>
                  <span className="font-mono font-bold text-xs bg-forest-900 text-mustard-400 px-3 py-1 rounded-lg">
                    {state.animations.speed.toFixed(2).replace(/\.00$/, '.0')}x
                  </span>
                </div>
                <input
                  id="anim-speed-slider"
                  type="range"
                  min={0.5}
                  max={2.0}
                  step={0.25}
                  value={state.animations.speed}
                  onChange={(e) =>
                    onUpdateState((prev) => ({
                      ...prev,
                      animations: { ...prev.animations, speed: Number(e.target.value) },
                    }))
                  }
                  className="w-full accent-forest-900 cursor-pointer"
                />
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
              <h3 className="text-xs font-extrabold uppercase text-forest-900 dark:text-mustard-400 mb-3">
                Admin Security Audit Trail
              </h3>
              <div className="space-y-2 max-h-56 overflow-y-auto text-xs">
                {state.auditLogs.map((a, i) => (
                  <div
                    key={i}
                    className="p-3 rounded-xl bg-cream dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-2"
                  >
                    <span className="font-semibold">{a.action}</span>
                    <span className="font-mono text-[11px] text-slate-500 whitespace-nowrap">
                      {a.timestamp}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 9: FULL-STACK SQL & API BLUEPRINT */}
        {activeTab === 'architecture' && (
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 space-y-6">
            <div>
              <h2 className="text-xl font-extrabold text-forest-950 dark:text-white flex items-center gap-2">
                <Server className="w-5 h-5 text-sky-600 dark:text-mustard-400" />
                <span>PostgreSQL Schema & HMAC Verification Blueprint</span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Reference architecture for atomic seat locking and HMAC-SHA256 payment verification.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-slate-950 text-slate-200 p-5 rounded-xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-mustard-400">
                    1. PostgreSQL Atomic Seat Lock Schema
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard?.writeText(SQL_SNIPPET);
                      onToast('SQL schema copied!');
                    }}
                    className="text-[11px] bg-white/10 hover:bg-white/20 px-2.5 py-1 rounded font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Copy className="w-3 h-3" /> Copy SQL
                  </button>
                </div>
                <pre className="text-[11px] font-mono overflow-x-auto text-emerald-300 leading-relaxed">
                  {SQL_SNIPPET}
                </pre>
              </div>

              <div className="bg-slate-950 text-slate-200 p-5 rounded-xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-mustard-400">
                    2. Next.js Server-Side HMAC Verification
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard?.writeText(NODE_SNIPPET);
                      onToast('API snippet copied!');
                    }}
                    className="text-[11px] bg-white/10 hover:bg-white/20 px-2.5 py-1 rounded font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Copy className="w-3 h-3" /> Copy API
                  </button>
                </div>
                <pre className="text-[11px] font-mono overflow-x-auto text-sky-300 leading-relaxed">
                  {NODE_SNIPPET}
                </pre>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
