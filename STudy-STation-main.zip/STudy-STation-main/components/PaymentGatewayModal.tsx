'use client';

import React, { useState } from 'react';
import { Building2, CreditCard, Lock, QrCode, ShieldCheck, Wallet, X } from 'lucide-react';
import type { GatewayMethod, PaymentContext, PaymentGatewaySettings } from '@/lib/types';
import { getISTDateInfo } from '@/lib/study-station';
import { DeterministicUpiQrSvg } from './BrandGraphics';

interface PaymentGatewayModalProps {
  context: PaymentContext | null;
  settings: PaymentGatewaySettings;
  onClose: () => void;
  onVerifySuccess: (result: {
    paymentId: string;
    signature: string;
    methodLabel: string;
  }) => void;
  onToast: (msg: string) => void;
}

export default function PaymentGatewayModal({
  context,
  settings,
  onClose,
  onVerifySuccess,
  onToast,
}: PaymentGatewayModalProps) {
  const [method, setMethod] = useState<GatewayMethod>(settings.enableUpi ? 'upi' : 'card');
  const [vpa, setVpa] = useState('student@okicici');
  const [cardHolder, setCardHolder] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [bank, setBank] = useState('State Bank of India (SBI)');
  const [wallet, setWallet] = useState('Amazon Pay Wallet');
  const [verifying, setVerifying] = useState(false);

  if (!context) return null;

  const orderId = context.serverOrderId || 'order_SS_PENDING';
  const balance = Math.max(0, context.fullFee - context.amount);
  const deadlineStr = getISTDateInfo(Number(settings.balanceDeadlineDays || 7)).dateStr;
  const upiUri = `upi://pay?pa=${encodeURIComponent(settings.upiId)}&pn=${encodeURIComponent(
    settings.merchantName
  )}&am=${context.amount}&cu=INR&tn=${encodeURIComponent(orderId)}`;

  const formatCardInput = (raw: string) => {
    const digits = raw.replace(/\D/g, '').substring(0, 16);
    setCardNumber(digits.replace(/(.{4})/g, '$1 ').trim());
  };

  const handleSubmitVerification = async () => {
    if (method === 'card') {
      const cleanDigits = cardNumber.replace(/\s/g, '');
      if (cleanDigits.length < 12 || cardExpiry.trim().length < 4 || cardCvv.trim().length < 3) {
        onToast('Please enter a valid Card Number, Expiry (MM/YY), and CVV.');
        return;
      }
    }

    setVerifying(true);
    try {
      const res = await fetch('/api/payments/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId,
          amountInr: context.amount,
          mode: settings.mode,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.verified) {
        onToast(data.error || 'Gateway signature verification failed.');
        setVerifying(false);
        return;
      }

      // Immediately clear sensitive card state (never persisted)
      setCardNumber('');
      setCardCvv('');

      const methodLabels: Record<GatewayMethod, string> = {
        upi: `${settings.provider} UPI (${vpa || 'QR'})`,
        card: `${settings.provider} Tokenized Card`,
        netbanking: `${settings.provider} NetBanking (${bank})`,
        wallets: `${settings.provider} Wallet (${wallet})`,
      };

      onVerifySuccess({
        paymentId: data.paymentId,
        signature: data.signature,
        methodLabel: methodLabels[method],
      });
    } catch {
      onToast('Network error verifying payment signature.');
    } finally {
      setVerifying(false);
    }
  };

  const methods: Array<{ key: GatewayMethod; label: string; enabled: boolean; icon: React.ReactNode }> = [
    { key: 'upi', label: 'UPI Apps', enabled: settings.enableUpi, icon: <QrCode className="w-4 h-4" /> },
    { key: 'card', label: 'Card', enabled: settings.enableCard, icon: <CreditCard className="w-4 h-4" /> },
    {
      key: 'netbanking',
      label: 'NetBanking',
      enabled: settings.enableNetbanking,
      icon: <Building2 className="w-4 h-4" />,
    },
    { key: 'wallets', label: 'Wallets', enabled: settings.enableWallets, icon: <Wallet className="w-4 h-4" /> },
  ];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="pg-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-forest-950/80 backdrop-blur-sm overflow-y-auto"
    >
      <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-5 sm:p-6 shadow-2xl border border-slate-200 dark:border-slate-700 relative my-auto text-slate-900 dark:text-slate-100">
        <button
          type="button"
          onClick={onClose}
          aria-label="Close Payment Gateway"
          className="absolute top-4 right-4 w-9 h-9 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 flex items-center justify-center cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="w-10 h-10 rounded-xl bg-forest-900 text-mustard-400 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-bold text-indigo-700 dark:text-indigo-400">
              {settings.provider} Checkout · {settings.mode === 'LIVE' ? 'Live Production' : 'Sandbox Test'}
            </p>
            <h3 id="pg-modal-title" className="text-lg font-extrabold text-forest-950 dark:text-white">
              {settings.merchantName}
            </h3>
          </div>
        </div>

        {/* Order Summary */}
        <div className="bg-forest-950 text-white rounded-xl p-4 my-4 flex items-center justify-between gap-3">
          <div>
            <p className="text-[11px] font-mono text-slate-400">
              Server Order: <span className="text-mustard-400 font-bold">{orderId}</span>
            </p>
            <p className="text-xs font-bold mt-0.5">{context.purposeLabel}</p>
            <p className="text-[11px] text-slate-300 mt-0.5">
              {context.name} · +91 {context.phone}
            </p>
            <p className="text-[11px] text-emerald-300 font-semibold mt-1">
              {context.isPartial
                ? `Temporary Lock · Pay remaining ₹${balance} by ${deadlineStr}`
                : '100% Full Fee Settlement'}
            </p>
          </div>
          <div className="text-right shrink-0">
            <span className="text-[10px] uppercase text-slate-400 block">Payable</span>
            <span className="text-2xl font-mono font-bold tabular-nums text-mustard-400">
              ₹{context.amount}
            </span>
          </div>
        </div>

        {/* Method Tabs */}
        <div className="grid grid-cols-4 gap-1.5 mb-4">
          {methods
            .filter((m) => m.enabled)
            .map((m) => (
              <button
                key={m.key}
                type="button"
                onClick={() => setMethod(m.key)}
                className={`py-2.5 px-1.5 rounded-xl text-[11px] font-bold border transition-colors flex flex-col items-center justify-center gap-1 cursor-pointer ${
                  method === m.key
                    ? 'border-forest-900 bg-forest-900 text-white dark:border-mustard-400'
                    : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                }`}
              >
                {m.icon}
                <span>{m.label}</span>
              </button>
            ))}
        </div>

        {/* Method Panels */}
        {method === 'upi' && (
          <div className="bg-cream dark:bg-slate-800 rounded-xl p-4 border border-slate-200 dark:border-slate-700 mb-4">
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <div className="bg-white p-1.5 rounded-xl border border-slate-200 shrink-0">
                <DeterministicUpiQrSvg seed={upiUri} />
              </div>
              <div className="flex-1 space-y-2 w-full">
                <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  PhonePe · Google Pay · Paytm · BHIM
                </p>
                <div>
                  <label
                    htmlFor="pg-vpa-input"
                    className="block text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400 mb-1"
                  >
                    UPI ID (VPA)
                  </label>
                  <input
                    id="pg-vpa-input"
                    type="text"
                    value={vpa}
                    onChange={(e) => setVpa(e.target.value)}
                    placeholder="yourname@upi"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
                  />
                </div>
                <a
                  href={upiUri}
                  className="inline-block text-xs font-bold text-forest-800 dark:text-mustard-400 hover:underline"
                >
                  Open Installed UPI App
                </a>
              </div>
            </div>
          </div>
        )}

        {method === 'card' && (
          <div className="bg-cream dark:bg-slate-800 rounded-xl p-4 border border-slate-200 dark:border-slate-700 space-y-3 mb-4">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-forest-900 dark:text-white">
                Debit / Credit Card (Tokenized)
              </span>
              <span className="text-emerald-700 dark:text-emerald-400 font-semibold flex items-center gap-1">
                <Lock className="w-3 h-3" /> CVV Never Stored
              </span>
            </div>
            <input
              type="text"
              aria-label="Cardholder Name"
              value={cardHolder}
              onChange={(e) => setCardHolder(e.target.value)}
              placeholder="Cardholder Name"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-semibold"
            />
            <input
              type="text"
              aria-label="Card Number"
              maxLength={19}
              value={cardNumber}
              onChange={(e) => formatCardInput(e.target.value)}
              placeholder="Card Number (e.g. 4111 1111 1111 1111)"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
            />
            <div className="grid grid-cols-2 gap-3">
              <input
                type="text"
                aria-label="Card Expiry"
                maxLength={5}
                value={cardExpiry}
                onChange={(e) => setCardExpiry(e.target.value)}
                placeholder="MM/YY"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
              />
              <input
                type="password"
                aria-label="Card CVV"
                maxLength={4}
                value={cardCvv}
                onChange={(e) => setCardCvv(e.target.value)}
                placeholder="CVV"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-mono font-bold"
              />
            </div>
          </div>
        )}

        {method === 'netbanking' && (
          <div className="bg-cream dark:bg-slate-800 rounded-xl p-4 border border-slate-200 dark:border-slate-700 space-y-2 mb-4">
            <label
              htmlFor="pg-bank-select"
              className="block text-xs font-bold text-forest-900 dark:text-white"
            >
              Select Indian Bank
            </label>
            <select
              id="pg-bank-select"
              value={bank}
              onChange={(e) => setBank(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-bold"
            >
              <option value="State Bank of India (SBI)">State Bank of India (SBI)</option>
              <option value="HDFC Bank">HDFC Bank</option>
              <option value="ICICI Bank">ICICI Bank</option>
              <option value="Axis Bank">Axis Bank</option>
              <option value="Bank of Maharashtra">Bank of Maharashtra</option>
              <option value="Kotak Mahindra Bank">Kotak Mahindra Bank</option>
            </select>
          </div>
        )}

        {method === 'wallets' && (
          <div className="bg-cream dark:bg-slate-800 rounded-xl p-4 border border-slate-200 dark:border-slate-700 space-y-2 mb-4">
            <label
              htmlFor="pg-wallet-select"
              className="block text-xs font-bold text-forest-900 dark:text-white"
            >
              Select Digital Wallet
            </label>
            <select
              id="pg-wallet-select"
              value={wallet}
              onChange={(e) => setWallet(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-xs font-bold"
            >
              <option value="Amazon Pay Wallet">Amazon Pay Wallet</option>
              <option value="PhonePe Wallet">PhonePe Wallet</option>
              <option value="Paytm Wallet">Paytm Wallet</option>
              <option value="Mobikwik / Freecharge">Mobikwik / Freecharge</option>
            </select>
          </div>
        )}

        <button
          type="button"
          disabled={verifying}
          onClick={handleSubmitVerification}
          className="w-full bg-forest-900 hover:bg-forest-800 dark:bg-mustard-500 dark:hover:bg-mustard-400 text-white dark:text-forest-950 font-bold text-sm py-3.5 rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
        >
          <ShieldCheck className="w-4 h-4" />
          <span>
            {verifying
              ? 'Verifying Server Signature...'
              : `Verify Signature & Pay ₹${context.amount}`}
          </span>
        </button>
      </div>
    </div>
  );
}
