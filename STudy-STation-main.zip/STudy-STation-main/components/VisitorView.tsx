'use client';

import { motion } from 'motion/react';
import React from 'react';
import {
  ArrowRight,
  Check,
  ChevronDown,
  Clock,
  Copy,
  Crown,
  ExternalLink,
  MapPin,
  Moon,
  Phone,
  ShieldCheck,
  Sun,
  Users,
  Wifi,
  Wind,
  Zap,
  BookOpen,
} from 'lucide-react';
import type { AppState, CoursePlan, PrimaryView } from '@/lib/types';
import { getShiftSeatCounts } from '@/lib/study-station';
import { GallerySceneSvg } from './BrandGraphics';

interface VisitorViewProps {
  state: AppState;
  onSwitchView: (view: PrimaryView) => void;
  onBookShift: (shiftKey: string) => void;
  onCopyAddress: () => void;
}

function renderCourseIcon(icon: CoursePlan['icon']) {
  switch (icon) {
    case 'sun':
      return <Sun className="w-5 h-5" />;
    case 'cloud-sun':
      return <Clock className="w-5 h-5" />;
    case 'moon':
      return <Moon className="w-5 h-5" />;
    case 'crown':
      return <Crown className="w-5 h-5" />;
    default:
      return <BookOpen className="w-5 h-5" />;
  }
}

export default function VisitorView({
  state,
  onSwitchView,
  onBookShift,
  onCopyAddress,
}: VisitorViewProps) {
  const counts = getShiftSeatCounts(state, 'morning');
  const morningFee = state.courses.find((c) => c.key === 'morning')?.fee ?? 499;
  const fulltimeFee = state.courses.find((c) => c.key === 'fulltime')?.fee ?? 999;

  return (
    <div className="space-y-0">
      {/* Announcement Strip (Non-sticky, sits cleanly in flow) */}
      <div className="bg-forest-950 text-white text-xs py-2.5 px-4 border-b border-mustard-500/25">
        <div className="max-w-7xl mx-auto flex items-center justify-center gap-2 text-center flex-wrap">
          <span className="font-bold text-mustard-400 uppercase tracking-wider">Admission Open</span>
          <span aria-hidden="true" className="text-white/30">
            ·
          </span>
          <span className="text-forest-50 font-medium">{state.website.announcement}</span>
        </div>
      </div>

      {/* Hero Section */}
      <section className="bg-grid-pattern border-b border-forest-900/10 dark:border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-14 lg:pt-14 lg:pb-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
            <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
              <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-forest-800 dark:text-mustard-400">
                <span>{state.website.hoursBadge}</span>
                <span aria-hidden="true" className="text-slate-400">
                  ·
                </span>
                <span>All AC Rooms</span>
                <span aria-hidden="true" className="text-slate-400">
                  ·
                </span>
                <span>Razorpay & Cashfree Verified</span>
              </div>

              <h1
                className="text-4xl sm:text-5xl lg:text-[3.5rem] font-extrabold text-forest-950 dark:text-white tracking-tight leading-[1.1]"
                style={{ textWrap: 'balance' }}
              >
                A Quiet, Air-Conditioned Space Built to{' '}
                <span className="text-forest-700 dark:text-mustard-400">Study & Achieve</span>
              </h1>

              <div className="flex items-start gap-3.5 bg-mustard-100/80 dark:bg-forest-900/80 border border-mustard-500/30 dark:border-mustard-400/30 px-4 py-3.5 rounded-xl max-w-xl">
                <div className="w-9 h-9 rounded-lg bg-forest-900 text-mustard-400 flex items-center justify-center shrink-0 mt-0.5">
                  <Users className="w-4 h-4" />
                </div>
                <p className="text-xs sm:text-sm font-bold text-forest-950 dark:text-forest-50 leading-snug">
                  Ideal for UPSC, MPSC, NEET, JEE Aspirants, Banking/SSC Candidates & Working
                  Professionals
                </p>
              </div>

              <p className="text-base text-slate-600 dark:text-slate-300 max-w-2xl leading-relaxed">
                Reserve your exact desk cabin in Osmanpura, Chhatrapati Sambhajinagar. Choose an
                8-hour shift at ₹{morningFee}/month or a 24×7 dedicated cabin at ₹{fulltimeFee}
                /month with real-time seat locking and instant digital admission receipts.
              </p>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => onSwitchView('booking')}
                  className="inline-flex items-center justify-center gap-2.5 bg-forest-900 hover:bg-forest-800 dark:bg-mustard-500 dark:hover:bg-mustard-400 text-white dark:text-forest-950 font-bold text-sm px-6 py-3.5 rounded-xl transition-colors cursor-pointer whitespace-nowrap"
                >
                  <span>Start Online Admission</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <a
                  href="#visitor-plans-section"
                  className="inline-flex items-center justify-center gap-2 bg-white dark:bg-slate-900 hover:bg-forest-50 dark:hover:bg-slate-800 text-forest-900 dark:text-white border border-slate-200 dark:border-slate-700 font-bold text-sm px-6 py-3.5 rounded-xl transition-colors whitespace-nowrap"
                >
                  <span>Compare Plans (₹{morningFee} / ₹{fulltimeFee})</span>
                </a>
              </div>
            </div>

            {/* Right Architectural Room Card */}
            <div className="lg:col-span-5 flex flex-col">
              <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm flex-1 flex flex-col justify-between gap-4">
                <div className="rounded-xl bg-[#EAE6DF] dark:bg-slate-800 p-4 border border-stone-300/60 dark:border-slate-700">
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <div>
                      <p className="text-base font-extrabold text-forest-900 dark:text-mustard-400 leading-none">
                        {state.website.brandName}
                      </p>
                      <p className="text-xs font-serif italic text-forest-700 dark:text-slate-300 mt-1">
                        {state.website.tagline}
                      </p>
                    </div>
                    <span className="text-[11px] font-mono font-bold text-forest-900 dark:text-emerald-300">
                      Silent AC Hall
                    </span>
                  </div>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src="/assets/aistudio/file_00000000a38c8207801c68ac0c617f81_59830089.png"
                    alt="STudy STation Reading Room Interior"
                    className="w-full h-44 object-cover rounded-lg shadow-sm"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  {[
                    { icon: Wind, label: 'Central AC Hall' },
                    { icon: Zap, label: 'Power at Every Desk' },
                    { icon: Wifi, label: 'High-Speed Wi-Fi' },
                    { icon: ShieldCheck, label: '24×7 CCTV Secured' },
                  ].map((badge, idx) => {
                    const IconComponent = badge.icon;
                    return (
                      <motion.div
                        key={idx}
                        initial={{ opacity: 0, y: 12, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        whileHover={{ scale: 1.04, y: -3, boxShadow: '0 8px 20px rgba(0,0,0,0.08)' }}
                        whileTap={{ scale: 0.97 }}
                        transition={{ duration: 0.3, delay: idx * 0.06, type: 'spring', stiffness: 350, damping: 20 }}
                        className="flex items-center gap-2 rounded-xl bg-cream dark:bg-slate-800/80 px-3.5 py-2.5 border border-slate-200/90 dark:border-slate-700 cursor-pointer"
                      >
                        <motion.div whileHover={{ rotate: [0, -10, 10, 0] }} transition={{ duration: 0.4 }}>
                          <IconComponent className="w-4 h-4 text-forest-700 dark:text-mustard-400 shrink-0" />
                        </motion.div>
                        <span className="text-[11px] font-bold text-forest-950 dark:text-slate-100">
                          {badge.label}
                        </span>
                      </motion.div>
                    );
                  })}
                </div>

                <div className="flex items-center justify-between gap-3 pt-1">
                  <div>
                    <p className="text-xs font-bold text-forest-900 dark:text-white">
                      Atomic Seat Locking & Digital Receipts
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      Partial lock or 100% full admission payment
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => onSwitchView('booking')}
                    className="bg-forest-900 hover:bg-forest-800 dark:bg-mustard-500 dark:hover:bg-mustard-400 text-white dark:text-forest-950 text-xs font-bold px-4 py-2.5 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    Select Seat
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* 4-Column KPI Strip Below Hero */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-10">
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
              <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Total AC Cabins
              </p>
              <p className="text-2xl font-mono font-bold tabular-nums text-forest-900 dark:text-white mt-1">
                {counts.total}
              </p>
            </div>
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
              <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Available (Morning)
              </p>
              <p className="text-2xl font-mono font-bold tabular-nums text-emerald-700 dark:text-emerald-400 mt-1">
                {counts.available}
              </p>
            </div>
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
              <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                8-Hour Shift Plan
              </p>
              <p className="text-2xl font-mono font-bold tabular-nums text-crimson-600 dark:text-amber-400 mt-1">
                ₹{morningFee}
                <span className="text-xs font-sans font-medium text-slate-500 dark:text-slate-400">
                  /mo
                </span>
              </p>
            </div>
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
              <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Full-Time 24×7 Cabin
              </p>
              <p className="text-2xl font-mono font-bold tabular-nums text-forest-900 dark:text-mustard-400 mt-1">
                ₹{fulltimeFee}
                <span className="text-xs font-sans font-medium text-slate-500 dark:text-slate-400">
                  /mo
                </span>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Reading Room Tour */}
      <section className="bg-white dark:bg-slate-900/50 py-14 border-b border-forest-900/10 dark:border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-8">
            <p className="text-xs font-bold uppercase tracking-wider text-forest-700 dark:text-mustard-400">
              Reading Room Tour
            </p>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-forest-950 dark:text-white mt-1">
              Inside {state.website.brandName} Reading Hall
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {state.website.gallery.map((item, idx) => (
              <div
                key={idx}
                className="bg-cream dark:bg-slate-900 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800"
              >
                <GallerySceneSvg variant={idx} />
                <div className="p-4 flex items-center justify-between gap-2">
                  <h3 className="font-bold text-forest-950 dark:text-white text-sm">
                    {item.title}
                  </h3>
                  <span className="text-xs font-semibold text-forest-700 dark:text-mustard-400 whitespace-nowrap">
                    AC Hall
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Courses, Shifts & Membership Plans */}
      <section
        id="visitor-plans-section"
        className="bg-grid-pattern py-14 border-b border-forest-900/10 dark:border-white/10"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-10">
            <p className="text-xs font-bold uppercase tracking-wider text-forest-700 dark:text-mustard-400">
              Courses, Shifts & Membership Plans
            </p>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-forest-950 dark:text-white mt-1">
              Choose Your Shift or Full-Time Reserved Cabin
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-300 mt-2">
              Book with a configurable Partial Seat Lock (₹{state.paymentGateway.tokenAmount}) or
              complete Full Payment via Razorpay / Cashfree UPI, Cards & NetBanking.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
            {state.courses.map((course) => {
              const isVip = course.key === 'fulltime';
              return (
                <div
                  key={course.key}
                  className={`rounded-2xl p-6 flex flex-col justify-between border ${
                    isVip
                      ? 'bg-forest-900 text-white border-mustard-400'
                      : 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-4">
                      <span
                        className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                          isVip
                            ? 'bg-mustard-400 text-forest-950'
                            : 'bg-forest-50 dark:bg-slate-800 text-forest-900 dark:text-mustard-400'
                        }`}
                      >
                        {renderCourseIcon(course.icon)}
                      </span>
                      <span
                        className={`text-xs font-semibold ${
                          isVip ? 'text-mustard-400' : 'text-slate-500 dark:text-slate-400'
                        }`}
                      >
                        {course.badge}
                      </span>
                    </div>

                    <h3 className="text-lg font-extrabold">{course.name}</h3>
                    <p
                      className={`text-xs font-semibold mt-1 ${
                        isVip ? 'text-mustard-300' : 'text-forest-700 dark:text-emerald-400'
                      }`}
                    >
                      {course.schedule}
                    </p>

                    <div
                      className={`my-5 py-4 border-y ${
                        isVip ? 'border-white/15' : 'border-slate-100 dark:border-slate-800'
                      }`}
                    >
                      <span
                        className={`text-xs font-semibold block ${
                          isVip ? 'text-forest-100' : 'text-slate-500 dark:text-slate-400'
                        }`}
                      >
                        Monthly Admission Fee
                      </span>
                      <div className="flex items-baseline gap-1 mt-1">
                        <span
                          className={`text-3xl font-mono font-bold tabular-nums ${
                            isVip
                              ? 'text-mustard-400'
                              : 'text-crimson-600 dark:text-mustard-400'
                          }`}
                        >
                          ₹{course.fee}
                        </span>
                        <span
                          className={`text-xs ${
                            isVip ? 'text-forest-100' : 'text-slate-500 dark:text-slate-400'
                          }`}
                        >
                          / month
                        </span>
                      </div>
                    </div>

                    <ul
                      className={`space-y-2 text-xs ${
                        isVip ? 'text-forest-50' : 'text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      <li className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 shrink-0" />
                        <span>
                          {isVip ? 'Permanent seat locked 24×7' : 'Choose exact seat number'}
                        </span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 shrink-0" />
                        <span>All AC Hall + Individual Power Outlet</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 shrink-0" />
                        <span>Partial Lock or Full Payment</span>
                      </li>
                    </ul>
                  </div>

                  <button
                    type="button"
                    onClick={() => onBookShift(course.key)}
                    className={`w-full mt-6 font-bold text-xs py-3 px-4 rounded-xl transition-colors cursor-pointer whitespace-nowrap ${
                      isVip
                        ? 'bg-mustard-400 hover:bg-mustard-300 text-forest-950'
                        : 'bg-forest-900 hover:bg-forest-800 dark:bg-mustard-500 dark:hover:bg-mustard-400 text-white dark:text-forest-950'
                    }`}
                  >
                    Book {course.name}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* FAQs Section */}
      <section className="bg-cream dark:bg-slate-950 py-14 border-b border-forest-900/10 dark:border-white/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <p className="text-xs font-bold uppercase tracking-wider text-forest-700 dark:text-mustard-400">
              Frequently Asked Questions
            </p>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-forest-950 dark:text-white mt-1">
              Admissions, Seat Lock & Payment FAQs
            </h2>
          </div>

          <div className="space-y-3">
            {state.website.faqs.map((faq, idx) => (
              <details
                key={idx}
                className="bg-white dark:bg-slate-900 rounded-xl p-5 border border-slate-200 dark:border-slate-800 group"
              >
                <summary className="font-bold text-sm text-forest-950 dark:text-white cursor-pointer flex items-center justify-between gap-4 list-none">
                  <span>{faq.q}</span>
                  <ChevronDown className="w-4 h-4 text-slate-500 shrink-0 transition-transform group-open:rotate-180" />
                </summary>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-3 leading-relaxed border-t border-slate-100 dark:border-slate-800 pt-3">
                  {faq.a}
                </p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* Contact & Campus Location */}
      <section className="bg-white dark:bg-slate-900/50 py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            <div className="lg:col-span-5 flex flex-col justify-between gap-5">
              <div className="bg-cream dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800">
                <p className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Admission Helpline
                </p>
                <a
                  href={`tel:${state.website.phone}`}
                  className="text-2xl sm:text-3xl font-mono font-bold tabular-nums text-forest-900 dark:text-mustard-400 block mt-1"
                >
                  {state.website.phone}
                </a>
                <div className="grid grid-cols-2 gap-3 mt-4">
                  <a
                    href={`tel:${state.website.phone}`}
                    className="flex items-center justify-center gap-2 bg-forest-900 hover:bg-forest-800 text-white font-bold text-xs py-3 rounded-xl transition-colors"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Call Now</span>
                  </a>
                  <a
                    href={`https://wa.me/91${state.website.phone}?text=Hello%20STudy%20STation!%20I%20would%20like%20to%20enquire%20about%20seat%20admission.`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 bg-[#1F9D55] hover:bg-[#198748] text-white font-bold text-xs py-3 rounded-xl transition-colors"
                  >
                    <span>WhatsApp Desk</span>
                  </a>
                </div>
              </div>

              <div className="bg-cream dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 flex-1 flex flex-col justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-mustard-400 text-forest-950 flex items-center justify-center shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                      Campus Address
                    </p>
                    <p className="text-sm font-bold text-forest-950 dark:text-white mt-1 leading-snug">
                      {state.website.address}
                    </p>
                  </div>
                </div>
                <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={onCopyAddress}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-forest-900 dark:text-mustard-400 hover:underline cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Address</span>
                  </button>
                  <a
                    href="https://www.google.com/maps/search/?api=1&query=Osmanpura+Chhatrapati+Sambhajinagar+431001"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-bold bg-forest-900 text-white px-4 py-2 rounded-lg hover:bg-forest-800 transition-colors"
                  >
                    <span>Google Maps</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>

            <div className="lg:col-span-7 bg-cream dark:bg-slate-900 rounded-2xl p-3 border border-slate-200 dark:border-slate-800 min-h-[300px] flex flex-col">
              <iframe
                title="STudy STation Osmanpura Map"
                className="w-full flex-1 min-h-[280px] rounded-xl border-0"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                src="https://www.openstreetmap.org/export/embed.html?bbox=75.3180%2C19.8600%2C75.3400%2C19.8740&layer=mapnik&marker=19.8670%2C75.3290"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
