'use client';

import React, { useCallback, useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { BookOpen, CheckCircle2 } from 'lucide-react';
import type {
  AppState,
  BookingPaymentMode,
  MemberRecord,
  PaymentContext,
  PrimaryView,
} from '@/lib/types';
import {
  cleanExpiredTempLocks,
  computeNewExpiryDate,
  createDefaultState,
  diffDaysFromTodayIST,
  evaluateTwoDayReminders,
  formatSeatCode,
  getISTDateInfo,
  getSeatStatusForShift,
  getShiftPrice,
  getShiftShortName,
  loadAppState,
  saveAppState,
} from '@/lib/study-station';
import Header from './Header';
import VisitorView from './VisitorView';
import BookingView from './BookingView';
import StudentView from './StudentView';
import AdminView from './AdminView';
import PaymentGatewayModal from './PaymentGatewayModal';
import BookingConfirmModal from './BookingConfirmModal';

export default function StudyStationApp() {
  const [state, setState] = useState<AppState>(() => createDefaultState());
  const [hydrated, setHydrated] = useState(false);

  const [activeView, setActiveView] = useState<PrimaryView>('visitor');
  const [bookingShift, setBookingShift] = useState<string>('morning');
  const [bookingSelectedSeat, setBookingSelectedSeat] = useState<number | null>(null);
  const [bookingPaymentMode, setBookingPaymentMode] = useState<BookingPaymentMode>('full');

  const [pendingPaymentContext, setPendingPaymentContext] = useState<PaymentContext | null>(null);
  const [confirmModalData, setConfirmModalData] = useState<{
    member: MemberRecord | null;
    txnId: string | null;
  }>({ member: null, txnId: null });

  const [loggedInStudentId, setLoggedInStudentId] = useState<string | null>(null);
  const [adminOtpVerified, setAdminOtpVerified] = useState(false);

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
  }, []);

  useEffect(() => {
    if (!toastMessage) return;
    const timer = setTimeout(() => setToastMessage(null), 3600);
    return () => clearTimeout(timer);
  }, [toastMessage]);

  useEffect(() => {
    const loaded = loadAppState();
    const cleaned = cleanExpiredTempLocks(loaded.tempSeatLocks);
    const initial = cleaned.changed ? { ...loaded, tempSeatLocks: cleaned.nextLocks } : loaded;

    // Run automatic 2-day IST reminder evaluation on startup without duplicates
    const evalRes = evaluateTwoDayReminders(initial);
    const finalState: AppState =
      evalRes.dispatchedCount > 0
        ? {
            ...initial,
            reminders: {
              ...initial.reminders,
              sentCycleKeys: evalRes.nextSentCycleKeys,
              logs: [...evalRes.newLogs, ...initial.reminders.logs].slice(0, 60),
            },
          }
        : initial;

    setState(finalState);
    saveAppState(finalState);
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    saveAppState(state);

    if (state.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }

    document.documentElement.style.setProperty('--anim-speed', String(state.animations.speed));
    if (state.animations.enabled) {
      document.body.classList.remove('animations-disabled');
    } else {
      document.body.classList.add('animations-disabled');
    }
  }, [state, hydrated]);

  const updateStateWithAudit = useCallback((updater: (prev: AppState) => AppState, auditMsg?: string) => {
    setState((prev) => {
      const next = updater(prev);
      if (!auditMsg) return next;
      const ist = getISTDateInfo(0);
      return {
        ...next,
        auditLogs: [
          { action: auditMsg, timestamp: `${ist.dateStr} ${ist.timeStr}` },
          ...next.auditLogs,
        ].slice(0, 50),
      };
    });
  }, []);

  const handleSwitchView = useCallback((view: PrimaryView) => {
    setActiveView(view);
    if (typeof window !== 'undefined') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, []);

  const handleToggleSeat = (seatNum: number) => {
    setState((prev) => {
      const nextLocks = { ...prev.tempSeatLocks };
      if (bookingSelectedSeat) {
        delete nextLocks[`${bookingShift}|${bookingSelectedSeat}`];
      }
      if (bookingSelectedSeat === seatNum) {
        setBookingSelectedSeat(null);
        return { ...prev, tempSeatLocks: nextLocks };
      }
      const lockMins = Number(prev.paymentGateway.lockDurationMins || 10);
      nextLocks[`${bookingShift}|${seatNum}`] = {
        expiresAt: Date.now() + lockMins * 60000,
        holder: 'current_session',
      };
      setBookingSelectedSeat(seatNum);
      showToast(`Seat ${formatSeatCode(seatNum)} temporarily locked for ${lockMins} minutes.`);
      return { ...prev, tempSeatLocks: nextLocks };
    });
  };

  const handleSubmitBooking = (payload: {
    name: string;
    phone: string;
    email: string;
    exam: string;
    joinedDate: string;
  }) => {
    if (!bookingSelectedSeat) {
      showToast('Please select an available green seat on the map first.');
      return;
    }

    const check = getSeatStatusForShift(state, bookingSelectedSeat, bookingShift, {
      currentSelectedSeat: bookingSelectedSeat,
      currentBookingShift: bookingShift,
    });

    if (check.status !== 'available') {
      showToast('Seat lock expired or reserved. Please pick another seat.');
      setBookingSelectedSeat(null);
      return;
    }

    const fullFee = getShiftPrice(state.courses, bookingShift);
    const pg = state.paymentGateway;
    const tokenAmt = Math.min(Number(pg.tokenAmount || 99), fullFee);
    const effectiveMode: BookingPaymentMode =
      !pg.allowTokenBooking && pg.allowFullPayment
        ? 'full'
        : pg.allowTokenBooking && !pg.allowFullPayment
          ? 'partial'
          : bookingPaymentMode;

    const isPartial = effectiveMode === 'partial';
    const payableNow = isPartial ? tokenAmt : fullFee;
    const expiryDate = computeNewExpiryDate(payload.joinedDate, 30);
    const orderId = 'order_' + Math.random().toString(36).substring(2, 10).toUpperCase();

    setPendingPaymentContext({
      contextType: 'new_booking',
      amount: payableNow,
      fullFee,
      isPartial,
      seatNumber: bookingSelectedSeat,
      shift: bookingShift,
      name: payload.name,
      phone: payload.phone,
      email: payload.email,
      exam: payload.exam,
      joinedDate: payload.joinedDate,
      expiryDate,
      serverOrderId: orderId,
      purposeLabel: `${formatSeatCode(bookingSelectedSeat)} · ${getShiftShortName(
        state.courses,
        bookingShift
      )} (${isPartial ? 'Option A: Partial Lock' : 'Option B: Full Payment'})`,
    });
  };

  const handlePaymentSuccess = ({
    paymentId,
    signature,
    methodLabel,
  }: {
    paymentId: string;
    signature: string;
    methodLabel: string;
  }) => {
    const ctx = pendingPaymentContext;
    if (!ctx) return;

    const istNow = getISTDateInfo(0);
    const ts = `${istNow.dateStr} ${istNow.timeStr}`;

    if (ctx.contextType === 'new_booking') {
      const balanceLeft = Math.max(0, ctx.fullFee - ctx.amount);
      const deadlineStr = ctx.isPartial
        ? getISTDateInfo(Number(state.paymentGateway.balanceDeadlineDays || 7)).dateStr
        : null;
      const memberId = 'SS-' + Math.floor(1006 + Math.random() * 8990);
      const joinedDate = ctx.joinedDate || istNow.dateStr;
      const expiryDate = ctx.expiryDate || computeNewExpiryDate(joinedDate, 30);

      const newMember: MemberRecord = {
        id: memberId,
        name: ctx.name,
        phone: ctx.phone,
        email: ctx.email,
        exam: ctx.exam || 'General',
        shift: ctx.shift,
        seatNumber: ctx.seatNumber,
        fee: ctx.fullFee,
        paidAmount: ctx.amount,
        balanceDue: balanceLeft,
        balanceDeadline: deadlineStr,
        applicationStatus: 'Approved',
        joinedDate,
        expiryDate,
        cycleId: `CYC-${expiryDate}`,
        paymentStatus: ctx.isPartial ? `Partial Paid (₹${balanceLeft} Due)` : 'Paid',
        notifications: [
          ctx.isPartial
            ? `Temporary reservation confirmed for ${formatSeatCode(
                ctx.seatNumber
              )}. Pay remaining ₹${balanceLeft} by ${deadlineStr}.`
            : `Full payment ₹${ctx.amount} verified! Seat ${formatSeatCode(
                ctx.seatNumber
              )} confirmed until ${expiryDate}.`,
        ],
      };

      setState((prev) => {
        const nextLocks = { ...prev.tempSeatLocks };
        delete nextLocks[`${ctx.shift}|${ctx.seatNumber}`];
        return {
          ...prev,
          tempSeatLocks: nextLocks,
          members: [newMember, ...prev.members],
          paymentGateway: {
            ...prev.paymentGateway,
            transactions: [
              {
                txnId: paymentId,
                orderId: ctx.serverOrderId || '',
                signature,
                studentId: memberId,
                studentName: ctx.name,
                phone: ctx.phone,
                seat: formatSeatCode(ctx.seatNumber),
                purpose: ctx.purposeLabel,
                method: methodLabel,
                amount: ctx.amount,
                status: 'Verified Paid',
                timestamp: ts,
              },
              ...prev.paymentGateway.transactions,
            ],
          },
        };
      });

      setBookingSelectedSeat(null);
      setPendingPaymentContext(null);
      setConfirmModalData({ member: newMember, txnId: paymentId });
      showToast(`Payment ${paymentId} verified! Seat ${formatSeatCode(newMember.seatNumber)} reserved.`);
      return;
    }

    if (ctx.contextType === 'student_balance' && ctx.memberId) {
      setState((prev) => ({
        ...prev,
        members: prev.members.map((m) =>
          m.id === ctx.memberId
            ? {
                ...m,
                paidAmount: Number(m.paidAmount || 0) + ctx.amount,
                balanceDue: 0,
                balanceDeadline: null,
                paymentStatus: 'Paid',
                notifications: [
                  `Remaining balance ₹${ctx.amount} verified (${paymentId}). Seat ${formatSeatCode(
                    m.seatNumber
                  )} is now 100% confirmed!`,
                  ...(m.notifications || []),
                ],
              }
            : m
        ),
        paymentGateway: {
          ...prev.paymentGateway,
          transactions: [
            {
              txnId: paymentId,
              orderId: ctx.serverOrderId || '',
              signature,
              studentId: ctx.memberId!,
              studentName: ctx.name,
              phone: ctx.phone,
              seat: formatSeatCode(ctx.seatNumber),
              purpose: ctx.purposeLabel,
              method: methodLabel,
              amount: ctx.amount,
              status: 'Verified Paid',
              timestamp: ts,
            },
            ...prev.paymentGateway.transactions,
          ],
        },
      }));
      setPendingPaymentContext(null);
      showToast(`Remaining balance ₹${ctx.amount} verified!`);
      return;
    }

    if (ctx.contextType === 'student_renewal' && ctx.memberId) {
      setState((prev) => ({
        ...prev,
        members: prev.members.map((m) => {
          if (m.id !== ctx.memberId) return m;
          const baseDateStr =
            diffDaysFromTodayIST(m.expiryDate) > 0 ? m.expiryDate : istNow.dateStr;
          const newExpiry = computeNewExpiryDate(baseDateStr, 30);
          return {
            ...m,
            expiryDate: newExpiry,
            cycleId: `CYC-${newExpiry}`,
            paymentStatus: 'Paid',
            balanceDue: 0,
            paidAmount: m.fee,
            notifications: [
              `Membership renewed (+30 days) until ${newExpiry}.`,
              ...(m.notifications || []),
            ],
          };
        }),
        paymentGateway: {
          ...prev.paymentGateway,
          transactions: [
            {
              txnId: paymentId,
              orderId: ctx.serverOrderId || '',
              signature,
              studentId: ctx.memberId!,
              studentName: ctx.name,
              phone: ctx.phone,
              seat: formatSeatCode(ctx.seatNumber),
              purpose: ctx.purposeLabel,
              method: methodLabel,
              amount: ctx.amount,
              status: 'Verified Paid',
              timestamp: ts,
            },
            ...prev.paymentGateway.transactions,
          ],
        },
      }));
      setPendingPaymentContext(null);
      showToast('Membership renewed (+30 days)!');
    }
  };

  const handleRenewMemberById = (memberId: string) => {
    const m = state.members.find((x) => x.id === memberId);
    if (!m) return;
    const baseDateStr =
      diffDaysFromTodayIST(m.expiryDate) > 0 ? m.expiryDate : getISTDateInfo(0).dateStr;
    const newExpiry = computeNewExpiryDate(baseDateStr, 30);
    updateStateWithAudit(
      (prev) => ({
        ...prev,
        members: prev.members.map((x) =>
          x.id === memberId
            ? {
                ...x,
                expiryDate: newExpiry,
                cycleId: `CYC-${newExpiry}`,
                paymentStatus: 'Paid',
                balanceDue: 0,
                paidAmount: x.fee,
                notifications: [
                  `Membership renewed (+30 days) until ${newExpiry}.`,
                  ...(x.notifications || []),
                ],
              }
            : x
        ),
      }),
      `Renewed membership for ${m.name} (#${m.id}) until ${newExpiry}`
    );
    showToast(`Renewed ${m.name} until ${newExpiry}.`);
  };

  const handleRunTwoDayReminders = () => {
    const res = evaluateTwoDayReminders(state);
    if (res.dispatchedCount === 0) {
      showToast('All 2-day reminders already sent for active cycles (0 duplicates).');
      return;
    }
    setState((prev) => ({
      ...prev,
      reminders: {
        ...prev.reminders,
        sentCycleKeys: res.nextSentCycleKeys,
        logs: [...res.newLogs, ...prev.reminders.logs].slice(0, 60),
      },
    }));
    showToast(`Dispatched ${res.dispatchedCount} unique 2-day IST reminder(s)!`);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header
        brandName={state.website.brandName}
        activeView={activeView}
        darkMode={state.darkMode}
        onSwitchView={handleSwitchView}
        onToggleDarkMode={() =>
          setState((prev) => ({ ...prev, darkMode: !prev.darkMode }))
        }
      />

      <main className="flex-1">
        <motion.div
          key={activeView}
          initial={state.animations.enabled ? { opacity: 0.92, y: 6 } : false}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.14 / Math.max(0.5, state.animations.speed) }}
        >
            {activeView === 'visitor' && (
              <VisitorView
                state={state}
                onSwitchView={handleSwitchView}
                onBookShift={(shiftKey) => {
                  setBookingShift(shiftKey);
                  setBookingSelectedSeat(null);
                  handleSwitchView('booking');
                }}
                onCopyAddress={() => {
                  navigator.clipboard?.writeText(state.website.address);
                  showToast('Campus address copied!');
                }}
              />
            )}

            {activeView === 'booking' && (
              <BookingView
                state={state}
                bookingShift={bookingShift}
                selectedSeat={bookingSelectedSeat}
                paymentMode={bookingPaymentMode}
                onSelectShift={(key) => {
                  setBookingShift(key);
                  setBookingSelectedSeat(null);
                }}
                onToggleSeat={handleToggleSeat}
                onSelectPaymentMode={setBookingPaymentMode}
                onSubmitBooking={handleSubmitBooking}
              />
            )}

            {activeView === 'student' && (
              <StudentView
                state={state}
                loggedInStudentId={loggedInStudentId}
                onLoginStudent={(memberId) => setLoggedInStudentId(memberId)}
                onLogoutStudent={() => setLoggedInStudentId(null)}
                onRegisterGoToBooking={({ name }) => {
                  showToast(`Welcome ${name}! Pick your course & seat to complete admission.`);
                  handleSwitchView('booking');
                }}
                onSwapSameShiftSeat={(memberId, newSeatNum) => {
                  const m = state.members.find((x) => x.id === memberId);
                  if (!m) return;
                  if (getSeatStatusForShift(state, newSeatNum, m.shift).status !== 'available') {
                    showToast('Sorry, that seat was just taken.');
                    return;
                  }
                  const oldCode = formatSeatCode(m.seatNumber);
                  const newCode = formatSeatCode(newSeatNum);
                  const note = `Changed seat ${oldCode} → ${newCode} on ${getISTDateInfo(0).dateStr}`;
                  setState((prev) => ({
                    ...prev,
                    members: prev.members.map((x) =>
                      x.id === memberId
                        ? {
                            ...x,
                            seatNumber: newSeatNum,
                            lastShiftChangeNote: note,
                            notifications: [note, ...(x.notifications || [])],
                          }
                        : x
                    ),
                  }));
                  showToast(`Seat switched to ${newCode}! Old seat ${oldCode} is now available.`);
                }}
                onSwitchShiftAndSeat={(memberId, targetShift, targetSeat) => {
                  const m = state.members.find((x) => x.id === memberId);
                  if (!m) return;
                  if (
                    getSeatStatusForShift(state, targetSeat, targetShift, {
                      excludeMemberId: memberId,
                    }).status !== 'available'
                  ) {
                    showToast('Seat was just booked. Please pick another seat.');
                    return;
                  }
                  const oldInfo = `${getShiftShortName(state.courses, m.shift)} (${formatSeatCode(
                    m.seatNumber
                  )})`;
                  const newFee = getShiftPrice(state.courses, targetShift);
                  const diff = Math.max(0, newFee - Number(m.fee));
                  const note = `Switched from ${oldInfo} → ${getShiftShortName(
                    state.courses,
                    targetShift
                  )} (${formatSeatCode(targetSeat)}) on ${getISTDateInfo(0).dateStr}`;

                  setState((prev) => ({
                    ...prev,
                    members: prev.members.map((x) => {
                      if (x.id !== memberId) return x;
                      const nextBal = Number(x.balanceDue || 0) + diff;
                      return {
                        ...x,
                        shift: targetShift,
                        seatNumber: targetSeat,
                        fee: newFee,
                        balanceDue: nextBal,
                        paymentStatus: diff > 0 ? `Balance Due (₹${nextBal})` : x.paymentStatus,
                        lastShiftChangeNote: note,
                        notifications: [note, ...(x.notifications || [])],
                      };
                    }),
                  }));
                  showToast('Shift updated! Old seat released automatically.');
                }}
                onUpdateProfile={(memberId, name, email) => {
                  setState((prev) => ({
                    ...prev,
                    members: prev.members.map((x) =>
                      x.id === memberId ? { ...x, name, email } : x
                    ),
                  }));
                  showToast('Student profile updated!');
                }}
                onPayRemainingBalance={(student) => {
                  if (!student.balanceDue) return;
                  setPendingPaymentContext({
                    contextType: 'student_balance',
                    memberId: student.id,
                    amount: student.balanceDue,
                    fullFee: student.fee,
                    isPartial: false,
                    seatNumber: student.seatNumber,
                    shift: student.shift,
                    name: student.name,
                    phone: student.phone,
                    email: student.email,
                    serverOrderId:
                      'order_' + Math.random().toString(36).substring(2, 10).toUpperCase(),
                    purposeLabel: `${formatSeatCode(student.seatNumber)} · Remaining Balance Settlement`,
                  });
                }}
                onRenewMembership={(student) => {
                  setPendingPaymentContext({
                    contextType: 'student_renewal',
                    memberId: student.id,
                    amount: student.fee,
                    fullFee: student.fee,
                    isPartial: false,
                    seatNumber: student.seatNumber,
                    shift: student.shift,
                    name: student.name,
                    phone: student.phone,
                    email: student.email,
                    serverOrderId:
                      'order_' + Math.random().toString(36).substring(2, 10).toUpperCase(),
                    purposeLabel: `${formatSeatCode(student.seatNumber)} · 30-Day Membership Renewal`,
                  });
                }}
                onToast={showToast}
              />
            )}

            {activeView === 'admin' && (
              <AdminView
                state={state}
                adminOtpVerified={adminOtpVerified}
                onUnlockAdmin={() => {
                  setAdminOtpVerified(true);
                  updateStateWithAudit(
                    (prev) => prev,
                    `Admin logged in via Mobile OTP (+91 ${state.adminMobile})`
                  );
                }}
                onLockAdmin={() => {
                  setAdminOtpVerified(false);
                  showToast('Admin Portal Locked.');
                }}
                onUpdateState={updateStateWithAudit}
                onRunReminders={handleRunTwoDayReminders}
                onRenewMember={handleRenewMemberById}
                onResetDefaults={() => {
                  const def = createDefaultState();
                  setState(def);
                  saveAppState(def);
                  showToast('System reset to factory defaults.');
                }}
                onToast={showToast}
              />
            )}
          </motion.div>
      </main>

      {/* Quiet Footer */}
      <footer className="bg-forest-950 text-white pt-9 pb-7 border-t-4 border-mustard-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center justify-center gap-2.5 mb-4">
            <BookOpen className="w-5 h-5 text-mustard-400" />
            <p className="font-serif italic text-xl sm:text-2xl text-mustard-400">
              &ldquo;Study in Peace, Succeed in Life&rdquo;
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-slate-400 pt-4 border-t border-white/10">
            <span>
              © 2026 <strong className="text-white">{state.website.brandName}</strong> · Osmanpura,
              Chhatrapati Sambhajinagar
            </span>
            <span aria-hidden="true">·</span>
            <button
              type="button"
              onClick={() => handleSwitchView('student')}
              className="text-mustard-400 hover:underline font-semibold cursor-pointer"
            >
              Student Portal
            </button>
            <span aria-hidden="true">·</span>
            <button
              type="button"
              onClick={() => handleSwitchView('admin')}
              className="text-mustard-400 hover:underline font-semibold cursor-pointer"
            >
              Admin OTP Login
            </button>
          </div>
        </div>
      </footer>

      {/* Payment Checkout Modal */}
      <PaymentGatewayModal
        context={pendingPaymentContext}
        settings={state.paymentGateway}
        onClose={() => setPendingPaymentContext(null)}
        onVerifySuccess={handlePaymentSuccess}
        onToast={showToast}
      />

      {/* Official Admission Pass Confirmation Modal */}
      <BookingConfirmModal
        member={confirmModalData.member}
        txnId={confirmModalData.txnId}
        courses={state.courses}
        helplinePhone={state.website.phone}
        onClose={() => setConfirmModalData({ member: null, txnId: null })}
        onOpenStudentDashboard={() => {
          if (confirmModalData.member) {
            setLoggedInStudentId(confirmModalData.member.id);
          }
          setConfirmModalData({ member: null, txnId: null });
          handleSwitchView('student');
        }}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 right-5 z-50 max-w-sm bg-forest-900 text-white px-4 py-3 rounded-xl shadow-xl border border-mustard-400/50 flex items-center gap-2.5"
        >
          <CheckCircle2 className="w-4 h-4 text-mustard-400 shrink-0" />
          <span className="text-xs font-bold">{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
