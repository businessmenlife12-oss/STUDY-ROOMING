'use client';

import React, { useState } from 'react';
import {
  ArrowLeftRight,
  Bell,
  CreditCard,
  FileDown,
  GraduationCap,
  IdCard,
  IndianRupee,
  LogIn,
  LogOut,
  Repeat,
} from 'lucide-react';
import type { AppState, MemberRecord } from '@/lib/types';
import {
  computeShiftChangeAdjustment,
  diffDaysFromTodayIST,
  formatSeatCode,
  generateReceiptHtml,
  getSeatStatusForShift,
  getShiftPrice,
  getShiftShortName,
} from '@/lib/study-station';

interface StudentViewProps {
  state: AppState;
  loggedInStudentId: string | null;
  onLoginStudent: (memberId: string) => void;
  onLogoutStudent: () => void;
  onRegisterGoToBooking: (payload: { name: string; phone: string; email: string }) => void;
  onSwapSameShiftSeat: (memberId: string, newSeatNum: number) => void;
  onSwitchShiftAndSeat: (memberId: string, targetShift: string, targetSeat: number) => void;
  onUpdateProfile: (memberId: string, name: string, email: string) => void;
  onPayRemainingBalance: (member: MemberRecord) => void;
  onRenewMembership: (member: MemberRecord) => void;
  onToast: (msg: string) => void;
}

export default function StudentView({
  state,
  loggedInStudentId,
  onLoginStudent,
  onLogoutStudent,
  onRegisterGoToBooking,
  onSwapSameShiftSeat,
  onSwitchShiftAndSeat,
  onUpdateProfile,
  onPayRemainingBalance,
  onRenewMembership,
  onToast,
}: StudentViewProps) {
  const [authTab, setAuthTab] = useState<'login' | 'register'>('login');
  const [identifier, setIdentifier] = useState('');
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regEmail, setRegEmail] = useState('');

  const [selectedNewSeat, setSelectedNewSeat] = useState<number | null>(null);
  const [targetShift, setTargetShift] = useState<string | null>(null);
  const [targetShiftSeat, setTargetShiftSeat] = useState<number | null>(null);

  const student = state.members.find((m) => m.id === loggedInStudentId) || null;
  const studentId = student?.id ?? null;
  const studentName = student?.name ?? '';
  const studentEmail = student?.email ?? '';

  const [profName, setProfName] = useState(studentName);
  const [profEmail, setProfEmail] = useState(studentEmail);

  React.useEffect(() => {
    if (studentId) {
      setProfName(studentName);
      setProfEmail(studentEmail);
      setSelectedNewSeat(null);
      setTargetShift(null);
      setTargetShiftSeat(null);
    }
  }, [studentId, studentName, studentEmail]);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const query = identifier.trim().toLowerCase();
    const found = state.members.find(
      (m) =>
        m.phone === query ||
        m.id.toLowerCase() === query ||
        `#${m.id.toLowerCase()}` === query
    );
    if (!found) {
      onToast('No student found with that Mobile Number or Pass ID.');
      return;
    }
    onLoginStudent(found.id);
    onToast(`Welcome back, ${found.name}!`);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onRegisterGoToBooking({
      name: regName.trim(),
      phone: regPhone.trim(),
      email: regEmail.trim(),
    });
  };

  const handleDownloadReceipt = () => {
    if (!student) return;
    const html = generateReceiptHtml(student, state.courses);
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `STudy_STation_Receipt_${student.id}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onToast(`Official receipt downloaded for #${student.id}.`);
  };

  if (!student) {
    return (
      <section className="bg-cream dark:bg-slate-950 py-10 lg:py-16 min-h-[82vh]">
        <div className="max-w-md mx-auto px-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-7 border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="text-center mb-5">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-forest-900 text-mustard-400 flex items-center justify-center mb-3">
                <GraduationCap className="w-7 h-7" />
              </div>
              <h1 className="text-2xl font-extrabold text-forest-950 dark:text-white">
                Student Portal
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Sign in with your Mobile or Pass ID, or register as a new student.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-slate-100 dark:bg-slate-800 mb-5">
              <button
                type="button"
                onClick={() => setAuthTab('login')}
                className={`py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                  authTab === 'login'
                    ? 'bg-forest-900 text-white'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Member Login
              </button>
              <button
                type="button"
                onClick={() => setAuthTab('register')}
                className={`py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                  authTab === 'register'
                    ? 'bg-forest-900 text-white'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                New Registration
              </button>
            </div>

            {authTab === 'login' ? (
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label
                    htmlFor="student-login-identifier"
                    className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Registered Mobile Number or Pass ID *
                  </label>
                  <input
                    id="student-login-identifier"
                    type="text"
                    required
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="e.g. 9823456710 or SS-1001"
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none text-sm font-mono font-bold"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-forest-900 hover:bg-forest-800 text-white font-bold text-sm py-3 rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <LogIn className="w-4 h-4 text-mustard-400" />
                  <span>Sign In to Dashboard</span>
                </button>
              </form>
            ) : (
              <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
                <div>
                  <label
                    htmlFor="reg-st-name"
                    className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Full Name *
                  </label>
                  <input
                    id="reg-st-name"
                    type="text"
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="Full Name"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-bold"
                  />
                </div>
                <div>
                  <label
                    htmlFor="reg-st-phone"
                    className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Mobile Number (10 Digits) *
                  </label>
                  <input
                    id="reg-st-phone"
                    type="tel"
                    required
                    pattern="[0-9]{10}"
                    maxLength={10}
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    placeholder="98XXXXXXXX"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-mono font-bold"
                  />
                </div>
                <div>
                  <label
                    htmlFor="reg-st-email"
                    className="block text-xs font-bold uppercase text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Email Address *
                  </label>
                  <input
                    id="reg-st-email"
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="student@email.com"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-medium"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-mustard-500 hover:bg-mustard-400 text-forest-950 font-bold text-sm py-3 rounded-xl transition-colors cursor-pointer"
                >
                  Create Student Account & Pick Seat
                </button>
              </form>
            )}

            <div className="mt-6 pt-5 border-t border-slate-100 dark:border-slate-800">
              <p className="text-xs font-bold uppercase text-slate-400 mb-2.5 text-center">
                Quick Demo Student Logins
              </p>
              <div className="grid grid-cols-1 gap-2">
                {state.members.slice(0, 4).map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => onLoginStudent(m.id)}
                    className="px-3 py-2 rounded-xl bg-forest-50 dark:bg-slate-800 hover:bg-forest-900 dark:hover:bg-mustard-500 text-forest-950 dark:text-slate-100 hover:text-white dark:hover:text-forest-950 border border-slate-200 dark:border-slate-700 text-xs font-bold transition-colors text-left flex items-center justify-between cursor-pointer"
                  >
                    <span>{m.name}</span>
                    <span className="font-mono">
                      #{m.id} · {formatSeatCode(m.seatNumber)}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  const currentSeatCode = formatSeatCode(student.seatNumber);
  const daysLeft = diffDaysFromTodayIST(student.expiryDate);
  const hasBalance = Boolean(student.balanceDue && student.balanceDue > 0);
  const studentTxns = state.paymentGateway.transactions.filter(
    (t) => t.studentId === student.id || t.phone === student.phone
  );

  const handleSelectTargetShift = (shiftKey: string) => {
    if (shiftKey === student.shift) {
      setTargetShift(null);
      setTargetShiftSeat(null);
      onToast(`You are already in ${getShiftShortName(state.courses, shiftKey)}.`);
      return;
    }
    setTargetShift(shiftKey);
    const checkCurrent = getSeatStatusForShift(state, student.seatNumber, shiftKey, {
      excludeMemberId: student.id,
    });
    setTargetShiftSeat(checkCurrent.status === 'available' ? student.seatNumber : null);
  };

  const targetShiftFee = targetShift ? getShiftPrice(state.courses, targetShift) : 0;
  const upgradeDiff = targetShift ? computeShiftChangeAdjustment(student.fee, targetShiftFee) : 0;

  return (
    <section className="bg-cream dark:bg-slate-950 py-8 lg:py-12 min-h-[82vh]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {/* Profile Header */}
        <div className="bg-forest-950 text-white rounded-2xl p-6 border border-mustard-400/40 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-mustard-400 text-forest-950 flex items-center justify-center shrink-0">
              <IdCard className="w-7 h-7" />
            </div>
            <div>
              <p className="text-xs font-mono text-mustard-400 font-bold">
                #{student.id} · Application: {student.applicationStatus}
              </p>
              <h1 className="text-2xl font-extrabold mt-0.5">{student.name}</h1>
              <p className="text-xs text-slate-300 font-mono mt-0.5">
                +91 {student.phone} · <span className="font-sans">{student.email || 'No email'}</span>
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={handleDownloadReceipt}
              className="bg-mustard-400 hover:bg-mustard-300 text-forest-950 text-xs font-bold px-4 py-2.5 rounded-xl flex items-center gap-2 cursor-pointer whitespace-nowrap"
            >
              <FileDown className="w-4 h-4" />
              <span>Download Official Receipt</span>
            </button>
            <button
              type="button"
              onClick={onLogoutStudent}
              className="bg-white/10 hover:bg-white/20 text-white text-xs font-bold px-4 py-2.5 rounded-xl border border-white/15 flex items-center gap-2 cursor-pointer whitespace-nowrap"
            >
              <LogOut className="w-4 h-4" />
              <span>Logout</span>
            </button>
          </div>
        </div>

        {/* 4 KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800">
            <span className="text-xs font-bold uppercase text-slate-400">Reserved Seat</span>
            <p className="text-2xl font-mono font-bold tabular-nums text-forest-950 dark:text-mustard-400 mt-1">
              {currentSeatCode}
            </p>
            <span className="text-xs font-semibold text-forest-700 dark:text-emerald-400">
              {hasBalance ? 'Temp Reserved (Partial)' : 'Confirmed Seat'}
            </span>
          </div>

          <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800">
            <span className="text-xs font-bold uppercase text-slate-400">Course / Shift</span>
            <p className="text-base font-extrabold text-forest-950 dark:text-white mt-1.5">
              {getShiftShortName(state.courses, student.shift)}
            </p>
            <span className="text-xs font-mono font-bold text-crimson-600 dark:text-mustard-400">
              ₹{student.fee} / Month
            </span>
          </div>

          <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800">
            <span className="text-xs font-bold uppercase text-slate-400">Booking Status</span>
            <p
              className={`text-sm font-extrabold mt-2 ${
                daysLeft < 0
                  ? 'text-crimson-600 dark:text-rose-400'
                  : hasBalance
                    ? 'text-amber-700 dark:text-amber-400'
                    : 'text-emerald-700 dark:text-emerald-400'
              }`}
            >
              {daysLeft < 0 ? 'Expired' : hasBalance ? 'Temp Reserved' : 'Confirmed Active'}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-mono tabular-nums">
              {daysLeft < 0
                ? `Expired ${Math.abs(daysLeft)}d ago`
                : hasBalance
                  ? `Balance ₹${student.balanceDue} due`
                  : `${daysLeft} days left`}
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800">
            <span className="text-xs font-bold uppercase text-slate-400">Expiry / Deadline</span>
            <p className="text-lg font-mono font-bold tabular-nums text-forest-950 dark:text-white mt-1.5">
              {hasBalance && student.balanceDeadline ? student.balanceDeadline : student.expiryDate}
            </p>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              {hasBalance ? 'Remaining Balance Due Date' : 'Auto 2-Day IST Alert'}
            </span>
          </div>
        </div>

        {/* Workspace Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left: Shift Change, Seat Swap, Profile */}
          <div className="lg:col-span-7 space-y-6">
            {/* Change Shift / Upgrade Plan */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-forest-700 dark:text-mustard-400">
                    Self-Service Shift Control
                  </p>
                  <h2 className="text-lg font-extrabold text-forest-950 dark:text-white">
                    Change Shift / Upgrade Plan
                  </h2>
                </div>
                <span className="text-xs font-mono font-bold text-slate-600 dark:text-slate-300">
                  Current: {currentSeatCode}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {state.courses.map((c) => {
                  const isCurrent = c.key === student.shift;
                  const isTarget = c.key === targetShift;
                  return (
                    <button
                      key={c.key}
                      type="button"
                      onClick={() => handleSelectTargetShift(c.key)}
                      className={`text-left p-3.5 rounded-xl border-2 transition-colors cursor-pointer ${
                        isTarget
                          ? 'border-forest-900 bg-forest-900 text-white dark:border-mustard-400'
                          : isCurrent
                            ? 'border-emerald-500/40 bg-emerald-50 dark:bg-emerald-950/30 text-forest-950 dark:text-white'
                            : 'border-slate-200 dark:border-slate-700 bg-cream dark:bg-slate-800 text-forest-950 dark:text-white'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-extrabold uppercase">{c.name}</span>
                        <span className="text-xs font-mono font-bold">₹{c.fee}</span>
                      </div>
                      <p
                        className={`text-[11px] mt-0.5 ${
                          isTarget ? 'text-forest-100' : 'text-slate-500 dark:text-slate-400'
                        }`}
                      >
                        {c.schedule} {isCurrent ? '(Current)' : ''}
                      </p>
                    </button>
                  );
                })}
              </div>

              {targetShift && targetShift !== student.shift && (
                <div className="bg-forest-50 dark:bg-slate-800 rounded-xl p-4 border border-forest-900/15 dark:border-slate-700 space-y-4">
                  <div className="text-xs font-semibold text-forest-950 dark:text-slate-200">
                    {getSeatStatusForShift(state, student.seatNumber, targetShift, {
                      excludeMemberId: student.id,
                    }).status === 'available'
                      ? `Your current seat ${currentSeatCode} is FREE in ${getShiftShortName(
                          state.courses,
                          targetShift
                        )}.`
                      : `Seat ${currentSeatCode} is occupied in ${getShiftShortName(
                          state.courses,
                          targetShift
                        )}. Choose another green seat below.`}
                  </div>

                  <div>
                    <p className="text-xs font-bold uppercase text-forest-900 dark:text-white mb-2">
                      Pick Seat in New Shift
                    </p>
                    <div className="grid grid-cols-5 sm:grid-cols-8 gap-1.5 max-h-44 overflow-y-auto p-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700">
                      {Array.from({ length: state.totalSeats }, (_, idx) => idx + 1).map((num) => {
                        const code = formatSeatCode(num);
                        const avail =
                          getSeatStatusForShift(state, num, targetShift, {
                            excludeMemberId: student.id,
                          }).status === 'available';
                        const isPicked = targetShiftSeat === num;
                        return (
                          <button
                            key={num}
                            type="button"
                            disabled={!avail}
                            onClick={() => setTargetShiftSeat(num)}
                            className={`py-1.5 px-1 rounded-lg font-mono text-[10px] font-bold ${
                              !avail
                                ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                                : isPicked
                                  ? 'bg-mustard-400 border border-mustard-600 text-forest-950'
                                  : 'bg-emerald-50 dark:bg-emerald-950/40 hover:bg-forest-900 border border-emerald-400 text-forest-900 dark:text-emerald-200 hover:text-white cursor-pointer'
                            }`}
                          >
                            {code}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs pt-2 border-t border-slate-200 dark:border-slate-700">
                    <span>
                      Adjustment:{' '}
                      <strong className="font-mono">
                        {upgradeDiff > 0 ? `+₹${upgradeDiff} Upgrade Due` : '₹0 Extra'}
                      </strong>
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        if (!targetShiftSeat) {
                          onToast('Please pick an available seat in the target shift.');
                          return;
                        }
                        onSwitchShiftAndSeat(student.id, targetShift, targetShiftSeat);
                        setTargetShift(null);
                        setTargetShiftSeat(null);
                      }}
                      className="bg-forest-900 hover:bg-forest-800 text-white font-bold text-xs px-4 py-2.5 rounded-xl flex items-center gap-1.5 cursor-pointer"
                    >
                      <Repeat className="w-3.5 h-3.5 text-mustard-400" />
                      <span>Confirm Shift & Seat Switch</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Same-Shift Seat Change */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-forest-700 dark:text-emerald-400">
                    Same-Shift Desk Swap
                  </p>
                  <h2 className="text-lg font-extrabold text-forest-950 dark:text-white">
                    Change Seat in Current Shift
                  </h2>
                </div>
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  Old {currentSeatCode} Releases
                </span>
              </div>

              <div className="grid grid-cols-5 sm:grid-cols-8 gap-2 max-h-48 overflow-y-auto p-1">
                {Array.from({ length: state.totalSeats }, (_, idx) => idx + 1)
                  .filter((num) => num !== student.seatNumber)
                  .filter(
                    (num) =>
                      getSeatStatusForShift(state, num, student.shift).status === 'available'
                  )
                  .map((num) => {
                    const code = formatSeatCode(num);
                    const isPicked = selectedNewSeat === num;
                    return (
                      <button
                        key={num}
                        type="button"
                        onClick={() => setSelectedNewSeat(isPicked ? null : num)}
                        className={`py-2 px-1 rounded-xl font-mono text-xs font-bold border transition-colors cursor-pointer ${
                          isPicked
                            ? 'bg-mustard-400 border-mustard-600 text-forest-950'
                            : 'bg-emerald-50 dark:bg-emerald-950/40 hover:bg-forest-900 border-emerald-400 text-forest-900 dark:text-emerald-200 hover:text-white'
                        }`}
                      >
                        {code}
                      </button>
                    );
                  })}
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <span className="text-xs text-slate-600 dark:text-slate-300">
                  New Seat:{' '}
                  <strong className="font-mono text-forest-950 dark:text-mustard-400">
                    {selectedNewSeat ? formatSeatCode(selectedNewSeat) : 'None selected'}
                  </strong>
                </span>
                <button
                  type="button"
                  onClick={() => {
                    if (!selectedNewSeat) {
                      onToast('Please select a new available seat first.');
                      return;
                    }
                    onSwapSameShiftSeat(student.id, selectedNewSeat);
                    setSelectedNewSeat(null);
                  }}
                  className="bg-forest-900 hover:bg-forest-800 text-white font-bold text-xs px-5 py-2.5 rounded-xl flex items-center justify-center gap-2 cursor-pointer"
                >
                  <ArrowLeftRight className="w-3.5 h-3.5 text-mustard-400" />
                  <span>Confirm Seat Change</span>
                </button>
              </div>
            </div>

            {/* Profile Editor */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800">
              <h2 className="text-lg font-extrabold text-forest-950 dark:text-white mb-4">
                Update Student Profile
              </h2>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  onUpdateProfile(student.id, profName.trim(), profEmail.trim());
                }}
                className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end"
              >
                <div>
                  <label
                    htmlFor="st-prof-name"
                    className="block text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400 mb-1"
                  >
                    Full Name
                  </label>
                  <input
                    id="st-prof-name"
                    type="text"
                    required
                    value={profName}
                    onChange={(e) => setProfName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold"
                  />
                </div>
                <div>
                  <label
                    htmlFor="st-prof-email"
                    className="block text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400 mb-1"
                  >
                    Email
                  </label>
                  <input
                    id="st-prof-email"
                    type="email"
                    required
                    value={profEmail}
                    onChange={(e) => setProfEmail(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-bold"
                  />
                </div>
                <button
                  type="submit"
                  className="bg-forest-900 hover:bg-forest-800 text-white font-bold text-xs py-2.5 px-4 rounded-xl cursor-pointer"
                >
                  Save Profile
                </button>
              </form>
            </div>
          </div>

          {/* Right: Fees, Balance, Payment History & Notifications */}
          <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 space-y-4 lg:sticky lg:top-20">
            <h2 className="text-lg font-extrabold text-forest-950 dark:text-white">
              Fees, Balance & Renewal
            </h2>

            <div className="bg-cream dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500 dark:text-slate-400">Total Plan Fee:</span>
                <strong className="font-mono tabular-nums">₹{student.fee}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 dark:text-slate-400">Amount Paid:</span>
                <strong className="font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
                  ₹{student.paidAmount ?? student.fee}
                </strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 dark:text-slate-400">Remaining Balance:</span>
                <strong className="font-mono tabular-nums text-crimson-600 dark:text-rose-400">
                  ₹{student.balanceDue || 0}
                </strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 dark:text-slate-400">Status:</span>
                <strong>{student.paymentStatus}</strong>
              </div>
              {student.lastShiftChangeNote && (
                <p className="pt-2 border-t border-slate-200 dark:border-slate-700 text-[11px] text-forest-800 dark:text-mustard-400 font-semibold">
                  {student.lastShiftChangeNote}
                </p>
              )}
            </div>

            {hasBalance && (
              <button
                type="button"
                onClick={() => onPayRemainingBalance(student)}
                className="w-full bg-crimson-600 hover:bg-crimson-500 text-white font-bold text-xs py-3.5 rounded-xl flex items-center justify-center gap-2 cursor-pointer"
              >
                <IndianRupee className="w-4 h-4" />
                <span>Pay Remaining Balance (₹{student.balanceDue}) Now</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => onRenewMembership(student)}
              className="w-full bg-mustard-500 hover:bg-mustard-400 text-forest-950 font-bold text-xs py-3.5 rounded-xl flex items-center justify-center gap-2 cursor-pointer"
            >
              <CreditCard className="w-4 h-4" />
              <span>Pay & Renew Membership (+30 Days)</span>
            </button>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
              <h3 className="text-xs font-extrabold uppercase text-slate-400 mb-2">
                My Verified Payment History
              </h3>
              <div className="space-y-2 max-h-44 overflow-y-auto">
                {studentTxns.length === 0 ? (
                  <p className="text-xs text-slate-400">No gateway transactions logged yet.</p>
                ) : (
                  studentTxns.map((t) => (
                    <div
                      key={t.txnId}
                      className="p-2.5 rounded-xl bg-cream dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs"
                    >
                      <div>
                        <p className="font-mono font-bold text-forest-950 dark:text-mustard-400">
                          {t.txnId}
                        </p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          {t.method} · {t.timestamp}
                        </p>
                      </div>
                      <span className="font-mono font-bold text-emerald-700 dark:text-emerald-400">
                        ₹{t.amount}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
              <h3 className="text-xs font-extrabold uppercase text-slate-400 mb-2">
                Booking & Payment Notifications
              </h3>
              <div className="space-y-2 max-h-40 overflow-y-auto text-xs">
                {(student.notifications || ['Active seat reservation verified.']).map((n, i) => (
                  <div
                    key={i}
                    className="p-2.5 rounded-xl bg-forest-50 dark:bg-slate-800 border border-forest-900/10 dark:border-slate-700 text-slate-700 dark:text-slate-200 flex items-start gap-2"
                  >
                    <Bell className="w-3.5 h-3.5 text-mustard-600 shrink-0 mt-0.5" />
                    <span>{n}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
