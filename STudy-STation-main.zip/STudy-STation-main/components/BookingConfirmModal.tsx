'use client';

import React from 'react';
import { CheckCircle2, GraduationCap, MessageSquare, X } from 'lucide-react';
import type { CoursePlan, MemberRecord } from '@/lib/types';
import { formatSeatCode, getShiftShortName } from '@/lib/study-station';

interface BookingConfirmModalProps {
  member: MemberRecord | null;
  txnId: string | null;
  courses: CoursePlan[];
  helplinePhone: string;
  onClose: () => void;
  onOpenStudentDashboard: () => void;
}

export default function BookingConfirmModal({
  member,
  txnId,
  courses,
  helplinePhone,
  onClose,
  onOpenStudentDashboard,
}: BookingConfirmModalProps) {
  if (!member) return null;

  const isPartial = Boolean(member.balanceDue && member.balanceDue > 0);
  const waMsg = `*STudy STation Reading Room*%0A*VERIFIED ADMISSION RECEIPT*%0A%0A• *Pass ID:* #${member.id}%0A• *Student:* ${encodeURIComponent(
    member.name
  )}%0A• *Seat:* ${formatSeatCode(member.seatNumber)}%0A• *Plan:* ${encodeURIComponent(
    getShiftShortName(courses, member.shift)
  )}%0A• *Paid:* ₹${member.paidAmount} | *Balance:* ₹${member.balanceDue || 0}%0A• *Valid Until:* ${
    member.expiryDate
  }`;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="confirm-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-forest-950/80 backdrop-blur-sm"
    >
      <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-2xl border border-mustard-400/60 relative text-center text-slate-900 dark:text-slate-100">
        <button
          type="button"
          onClick={onClose}
          aria-label="Close Confirmation Modal"
          className="absolute top-4 right-4 w-9 h-9 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 flex items-center justify-center cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="w-14 h-14 mx-auto rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 flex items-center justify-center mb-3">
          <CheckCircle2 className="w-8 h-8" />
        </div>
        <p className="text-xs font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
          {isPartial
            ? 'Partial Lock Verified · Temp Reservation'
            : 'Signature Verified · Full Reservation'}
        </p>
        <h3 id="confirm-modal-title" className="text-2xl font-extrabold text-forest-950 dark:text-white mt-1">
          Seat Reserved!
        </h3>

        <div className="bg-forest-900 text-white rounded-xl p-4 my-4 text-left space-y-2 border border-mustard-400/50">
          <div className="flex items-center justify-between border-b border-white/15 pb-2">
            <span className="text-xs font-bold text-mustard-400 uppercase">
              Official Admission Pass
            </span>
            <span className="text-xs font-mono font-bold">#{member.id}</span>
          </div>
          <p className="text-sm font-bold">
            {member.name} · +91 {member.phone}
          </p>
          <div className="grid grid-cols-2 gap-2 text-xs pt-1">
            <div>
              <span className="text-forest-100 text-[11px] block">Seat Number</span>
              <span className="font-mono font-bold text-mustard-400 text-lg">
                {formatSeatCode(member.seatNumber)}
              </span>
            </div>
            <div>
              <span className="text-forest-100 text-[11px] block">Valid / Deadline</span>
              <span className="font-mono font-bold text-emerald-300 text-sm">
                {isPartial && member.balanceDeadline ? `Due: ${member.balanceDeadline}` : member.expiryDate}
              </span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs pt-1">
            <div>
              <span className="text-forest-100 text-[11px] block">Plan & Balance</span>
              <span className="font-semibold">
                {isPartial
                  ? `Paid ₹${member.paidAmount} (₹${member.balanceDue} Due)`
                  : `${getShiftShortName(courses, member.shift)} (₹${member.fee})`}
              </span>
            </div>
            <div>
              <span className="text-forest-100 text-[11px] block">Gateway Payment ID</span>
              <span className="font-mono font-bold text-mustard-300">{txnId || 'VERIFIED'}</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <a
            href={`https://wa.me/91${helplinePhone}?text=${waMsg}`}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-[#1F9D55] hover:bg-[#198748] text-white font-bold text-xs py-3 rounded-xl flex items-center justify-center gap-1.5 transition-colors"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>WhatsApp Receipt</span>
          </a>
          <button
            type="button"
            onClick={onOpenStudentDashboard}
            className="bg-forest-900 hover:bg-forest-800 text-white font-bold text-xs py-3 rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <GraduationCap className="w-4 h-4 text-mustard-400" />
            <span>Student Dashboard</span>
          </button>
        </div>
      </div>
    </div>
  );
}
