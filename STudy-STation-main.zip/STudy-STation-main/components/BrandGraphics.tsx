import React from 'react';

export function BrandDeskLampEmblem({ className = 'w-10 h-10' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <path
        d="M18 52L60 18L102 52V104H18V52Z"
        stroke="#1B4332"
        strokeWidth="5.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="#F8F9F5"
      />
      <line x1="60" y1="20" x2="60" y2="34" stroke="#D4A017" strokeWidth="3" />
      <path d="M51 39C51 34 69 34 69 39H51Z" fill="#D4A017" />
      <circle cx="60" cy="40" r="3" fill="#FDE047" />
      <circle cx="44" cy="54" r="6.5" fill="#1B4332" />
      <path
        d="M36 66C36 63 40 62 44 62C47 62 50 64 51 67L54 78H67C69.5 78 71 80 71 82.5V99H64V85H44C39.5 85 36 81.5 36 77V66Z"
        fill="#1B4332"
      />
      <path
        d="M30 66V89H52M33 89V100M48 89V100"
        stroke="#1B4332"
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M62 74H92M77 74V100" stroke="#1B4332" strokeWidth="4.5" strokeLinecap="round" />
      <path d="M63 72L72 64L78 72H63Z" fill="#D4A017" />
    </svg>
  );
}

export function StudyHallIllustration() {
  return (
    <svg
      viewBox="0 0 400 145"
      className="w-full h-auto"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="Architectural illustration of STudy STation individual desk cabins"
    >
      <rect x="0" y="90" width="400" height="55" fill="#B8AFA2" />
      <g transform="translate(40, 32)">
        <rect x="0" y="16" width="16" height="14" rx="2" fill="#2D3748" />
        <circle cx="8" cy="11" r="8" fill="#2D6A4F" />
        <rect x="42" y="18" width="14" height="10" rx="1.5" fill="#FFF" stroke="#CBD5E1" />
      </g>
      <g transform="translate(165, 32)">
        <rect x="0" y="16" width="16" height="14" rx="2" fill="#2D3748" />
        <circle cx="8" cy="11" r="8" fill="#2D6A4F" />
        <rect x="42" y="18" width="14" height="10" rx="1.5" fill="#FFF" stroke="#CBD5E1" />
      </g>
      <g transform="translate(290, 32)">
        <rect x="0" y="16" width="16" height="14" rx="2" fill="#2D3748" />
        <circle cx="8" cy="11" r="8" fill="#2D6A4F" />
      </g>
      <rect x="10" y="62" width="380" height="12" rx="3" fill="#C68B59" />
      <rect x="10" y="74" width="380" height="5" fill="#9C6644" />
      <g transform="translate(45, 70)">
        <rect x="8" y="0" width="34" height="36" rx="8" fill="#1E293B" />
        <rect x="4" y="38" width="42" height="8" rx="4" fill="#0F172A" />
        <rect x="22" y="46" width="6" height="16" fill="#475569" />
      </g>
      <g transform="translate(175, 70)">
        <rect x="8" y="0" width="34" height="36" rx="8" fill="#1E293B" />
        <rect x="4" y="38" width="42" height="8" rx="4" fill="#0F172A" />
        <rect x="22" y="46" width="6" height="16" fill="#475569" />
      </g>
      <g transform="translate(305, 70)">
        <rect x="8" y="0" width="34" height="36" rx="8" fill="#1E293B" />
        <rect x="4" y="38" width="42" height="8" rx="4" fill="#0F172A" />
        <rect x="22" y="46" width="6" height="16" fill="#475569" />
      </g>
    </svg>
  );
}

export function GallerySceneSvg({ variant }: { variant: number }) {
  if (variant % 3 === 0) {
    return (
      <>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/assets/aistudio/file_0000000081c48211bfa328b5ac7cbfa5_3691bceb.png"
          alt="STudy STation Reading Hall Interior View"
          className="w-full h-48 object-cover"
          referrerPolicy="no-referrer"
        />
      </>
    );
  }
  if (variant % 3 === 1) {
    return (
      <>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/assets/aistudio/file_00000000442c8207bf3bec6805e4fe69_82cba5c9.png"
          alt="STudy STation Reading Hall Inspiration"
          className="w-full h-48 object-cover"
          referrerPolicy="no-referrer"
        />
      </>
    );
  }
  return (
    <>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/assets/aistudio/file_00000000fb0482118c2555c4d081d58e_7185dfbf.png"
        alt="STudy STation Study Desks and Hall"
        className="w-full h-48 object-cover"
        referrerPolicy="no-referrer"
      />
    </>
  );
}

/**
 * Renders a deterministic crisp SVG matrix representing a UPI QR code
 * without relying on external third-party image endpoints.
 */
export function DeterministicUpiQrSvg({ seed }: { seed: string }) {
  const size = 21;
  const cells: boolean[] = [];
  let hash = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    hash ^= seed.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }

  const isFinder = (r: number, c: number) => {
    const inTopLeft = r < 7 && c < 7;
    const inTopRight = r < 7 && c >= size - 7;
    const inBottomLeft = r >= size - 7 && c < 7;
    if (!inTopLeft && !inTopRight && !inBottomLeft) return null;
    const lr = r >= size - 7 ? r - (size - 7) : r;
    const lc = c >= size - 7 ? c - (size - 7) : c;
    if (lr === 0 || lr === 6 || lc === 0 || lc === 6) return true;
    if (lr >= 2 && lr <= 4 && lc >= 2 && lc <= 4) return true;
    return false;
  };

  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      const finder = isFinder(r, c);
      if (finder !== null) {
        cells.push(finder);
      } else {
        const bit = ((hash >>> ((r * size + c) % 24)) ^ (r * 7 + c * 13)) & 1;
        cells.push(bit === 1);
      }
    }
  }

  return (
    <svg
      viewBox={`0 0 ${size + 2} ${size + 2}`}
      className="w-28 h-28 rounded-xl bg-white p-1"
      role="img"
      aria-label="UPI Payment QR Code"
    >
      <rect width={size + 2} height={size + 2} fill="#FFFFFF" />
      {cells.map((filled, idx) => {
        if (!filled) return null;
        const r = Math.floor(idx / size);
        const c = idx % size;
        return <rect key={idx} x={c + 1} y={r + 1} width={1} height={1} fill="#0F291E" />;
      })}
    </svg>
  );
}
