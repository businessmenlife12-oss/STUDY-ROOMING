import type {
  AppState,
  CoursePlan,
  MemberRecord,
  ReminderLog,
  SeatCounts,
  SeatStatusResult,
} from './types';

export const STORAGE_KEY = 'study_station_edtech_production_v3';

export interface ISTDateInfo {
  dateStr: string;
  timeStr: string;
}

export function getISTDateInfo(offsetDays = 0, nowMs = Date.now()): ISTDateInfo {
  const now = new Date(nowMs);
  const utcMs = now.getTime() + now.getTimezoneOffset() * 60000;
  const istMs = utcMs + 5.5 * 3600000 + offsetDays * 86400000;
  const istDate = new Date(istMs);
  const yyyy = istDate.getUTCFullYear();
  const mm = String(istDate.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(istDate.getUTCDate()).padStart(2, '0');
  const hh = String(istDate.getUTCHours()).padStart(2, '0');
  const min = String(istDate.getUTCMinutes()).padStart(2, '0');
  return {
    dateStr: `${yyyy}-${mm}-${dd}`,
    timeStr: `${hh}:${min} IST`,
  };
}

export function diffDaysFromTodayIST(targetDateStr: string, nowMs = Date.now()): number {
  const todayStr = getISTDateInfo(0, nowMs).dateStr;
  const t1 = Date.parse(`${todayStr}T00:00:00Z`);
  const t2 = Date.parse(`${targetDateStr}T00:00:00Z`);
  return Math.round((t2 - t1) / 86400000);
}

export function computeNewExpiryDate(startDateStr: string, addDays = 30): string {
  const d = new Date(`${startDateStr}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + addDays);
  return d.toISOString().split('T')[0];
}

export function formatSeatCode(num: number): string {
  return 'S-' + String(num).padStart(2, '0');
}

export function getCourseByKey(courses: CoursePlan[], key: string): CoursePlan {
  return courses.find((c) => c.key === key) || courses[0];
}

export function getShiftDisplayName(courses: CoursePlan[], shiftKey: string): string {
  const c = getCourseByKey(courses, shiftKey);
  return `${c.name} (${c.schedule})`;
}

export function getShiftShortName(courses: CoursePlan[], shiftKey: string): string {
  return getCourseByKey(courses, shiftKey).name;
}

export function getShiftPrice(courses: CoursePlan[], shiftKey: string): number {
  return Number(getCourseByKey(courses, shiftKey).fee || 499);
}

export function cleanExpiredTempLocks(
  tempSeatLocks: AppState['tempSeatLocks'],
  nowMs = Date.now()
): { nextLocks: AppState['tempSeatLocks']; changed: boolean } {
  const nextLocks: AppState['tempSeatLocks'] = {};
  let changed = false;
  for (const [key, val] of Object.entries(tempSeatLocks || {})) {
    if (val && val.expiresAt > nowMs) {
      nextLocks[key] = val;
    } else {
      changed = true;
    }
  }
  return { nextLocks, changed };
}

export function getSeatStatusForShift(
  state: Pick<AppState, 'blockedSeats' | 'tempSeatLocks' | 'members'>,
  seatNum: number,
  shiftKey: string,
  options?: {
    excludeMemberId?: string | null;
    currentSelectedSeat?: number | null;
    currentBookingShift?: string | null;
    nowMs?: number;
  }
): SeatStatusResult {
  const nowMs = options?.nowMs ?? Date.now();
  if (state.blockedSeats.includes(seatNum)) {
    return { status: 'blocked', occupant: null };
  }

  const lockKey = `${shiftKey}|${seatNum}`;
  const activeLock = state.tempSeatLocks?.[lockKey];
  const isOwnSelection =
    options?.currentSelectedSeat === seatNum && options?.currentBookingShift === shiftKey;
  if (activeLock && activeLock.expiresAt > nowMs && !isOwnSelection) {
    return { status: 'locked', occupant: null };
  }

  const activeMembers = options?.excludeMemberId
    ? state.members.filter((m) => m.id !== options.excludeMemberId)
    : state.members;

  const fullTimeHolder = activeMembers.find(
    (m) => m.shift === 'fulltime' && m.seatNumber === seatNum && m.applicationStatus !== 'Rejected'
  );
  if (fullTimeHolder) {
    return { status: 'reserved', occupant: fullTimeHolder };
  }

  if (shiftKey === 'fulltime') {
    const anyShiftHolder = activeMembers.find(
      (m) => m.seatNumber === seatNum && m.applicationStatus !== 'Rejected'
    );
    if (anyShiftHolder) {
      return { status: 'reserved', occupant: anyShiftHolder };
    }
    return { status: 'available', occupant: null };
  }

  const shiftHolder = activeMembers.find(
    (m) => m.shift === shiftKey && m.seatNumber === seatNum && m.applicationStatus !== 'Rejected'
  );
  if (shiftHolder) {
    return { status: 'reserved', occupant: shiftHolder };
  }

  return { status: 'available', occupant: null };
}

export function getShiftSeatCounts(
  state: Pick<AppState, 'totalSeats' | 'blockedSeats' | 'tempSeatLocks' | 'members'>,
  shiftKey: string,
  nowMs = Date.now()
): SeatCounts {
  let available = 0;
  let reserved = 0;
  let blocked = 0;
  for (let i = 1; i <= state.totalSeats; i++) {
    const res = getSeatStatusForShift(state, i, shiftKey, { nowMs });
    if (res.status === 'available') available++;
    else if (res.status === 'reserved') reserved++;
    else if (res.status === 'blocked') blocked++;
  }
  return { total: state.totalSeats, available, reserved, blocked };
}

export function computeShiftChangeAdjustment(currentFee: number, targetFee: number): number {
  return Math.max(0, Number(targetFee) - Number(currentFee));
}

export function evaluateTwoDayReminders(
  state: AppState,
  nowMs = Date.now()
): {
  dispatchedCount: number;
  nextSentCycleKeys: Record<string, boolean>;
  newLogs: ReminderLog[];
} {
  const r = state.reminders;
  const istNow = getISTDateInfo(0, nowMs);
  const nextSentCycleKeys = { ...r.sentCycleKeys };
  const newLogs: ReminderLog[] = [];

  for (const member of state.members) {
    if (member.applicationStatus === 'Rejected') continue;
    if (diffDaysFromTodayIST(member.expiryDate, nowMs) === 2) {
      const cycle = member.cycleId || `CYC-${member.expiryDate}`;
      const smsKey = `${member.id}|${cycle}|SMS`;
      if (r.smsEnabled && !nextSentCycleKeys[smsKey]) {
        nextSentCycleKeys[smsKey] = true;
        newLogs.push({
          studentName: member.name,
          phone: member.phone,
          cycleId: cycle,
          channel: 'SMS',
          status: r.livePaidServiceApproved ? 'Sent via Paid SMS API' : 'Queued (Sandbox)',
          timestamp: `${istNow.dateStr} ${istNow.timeStr}`,
        });
      }
      const waKey = `${member.id}|${cycle}|WA`;
      if (r.whatsappEnabled && !nextSentCycleKeys[waKey]) {
        nextSentCycleKeys[waKey] = true;
        newLogs.push({
          studentName: member.name,
          phone: member.phone,
          cycleId: cycle,
          channel: 'WhatsApp',
          status: r.livePaidServiceApproved ? 'Delivered via WhatsApp API' : 'Queued (Sandbox)',
          timestamp: `${istNow.dateStr} ${istNow.timeStr}`,
        });
      }
    }
  }

  return {
    dispatchedCount: newLogs.length,
    nextSentCycleKeys,
    newLogs,
  };
}

export function createDefaultState(nowMs = Date.now()): AppState {
  const in2DaysIST = getISTDateInfo(2, nowMs).dateStr;
  const in5DaysIST = getISTDateInfo(5, nowMs).dateStr;
  const in18DaysIST = getISTDateInfo(18, nowMs).dateStr;
  const in25DaysIST = getISTDateInfo(25, nowMs).dateStr;
  const expired2DaysAgoIST = getISTDateInfo(-2, nowMs).dateStr;
  const joined30Ago = getISTDateInfo(-28, nowMs).dateStr;
  const todayIST = getISTDateInfo(0, nowMs);

  return {
    darkMode: false,
    adminMobile: '8308804099',
    totalSeats: 60,
    blockedSeats: [13, 44],
    tempSeatLocks: {},
    courses: [
      {
        key: 'morning',
        name: 'Morning Shift',
        schedule: '6:00 AM – 2:00 PM',
        fee: 499,
        badge: '8 Hours Shift',
        icon: 'sun',
      },
      {
        key: 'afternoon',
        name: 'Afternoon Shift',
        schedule: '2:30 PM – 10:30 PM',
        fee: 499,
        badge: '8 Hours Shift',
        icon: 'cloud-sun',
      },
      {
        key: 'night',
        name: 'Night Shift',
        schedule: '10:30 PM – 6:00 AM',
        fee: 499,
        badge: '8 Hours Shift',
        icon: 'moon',
      },
      {
        key: 'fulltime',
        name: 'Full-Time Reserved',
        schedule: '24 Hours Dedicated Cabin',
        fee: 999,
        badge: '24×7 Dedicated Cabin',
        icon: 'crown',
      },
    ],
    website: {
      brandName: 'STudy STation',
      tagline: 'Focus Today, Achieve Tomorrow',
      announcement:
        '24-Hour AC Reading Room & Study Center • Morning, Afternoon & Night Shifts at ₹499/mo • Full-Time Reserved at ₹999/mo',
      hoursBadge: '24-Hour Study Room (Open Everyday)',
      phone: '8308804099',
      address:
        'Office No: 02, First Floor, Costa Mapal, Osmanpura, Chhatrapati Sambhajinagar (Aurangabad), Maharashtra - 431001',
      gallery: [
        { title: 'Main AC Study Hall & Wooden Cabins', url: '' },
        { title: 'Quiet Focus Zone & Study Desk Rows', url: '' },
        { title: 'Individual Power Sockets & Ergonomic Seating', url: '' },
      ],
      faqs: [
        {
          q: 'How does Option A (Partial Seat Lock) vs Option B (Full Payment) work?',
          a: 'With Option A, you pay the configurable booking lock fee to temporarily reserve your seat and pay the remaining balance before the deadline. Option B confirms your seat immediately with a full official receipt.',
        },
        {
          q: 'Can I change my seat or switch shifts after booking?',
          a: 'Yes. Log into the Student Portal anytime to switch to another available seat in your shift or move to a different shift/plan with automatic release of your previous seat.',
        },
        {
          q: 'Which payment methods are supported?',
          a: 'We support Razorpay & Cashfree checkout including UPI (Google Pay, PhonePe, Paytm, BHIM), Debit Cards, Credit Cards, NetBanking, and Digital Wallets.',
        },
      ],
    },
    members: [
      {
        id: 'SS-1001',
        name: 'Aarav Kulkarni',
        phone: '9823456710',
        email: 'aarav.kulkarni@example.com',
        exam: 'UPSC / MPSC',
        shift: 'fulltime',
        seatNumber: 4,
        fee: 999,
        paidAmount: 999,
        balanceDue: 0,
        applicationStatus: 'Approved',
        joinedDate: joined30Ago,
        expiryDate: in18DaysIST,
        cycleId: 'CYC-' + in18DaysIST,
        paymentStatus: 'Paid',
        notifications: ['Seat S-04 confirmed under Full-Time Reserved Plan.'],
      },
      {
        id: 'SS-1002',
        name: 'Sneha Jadhav',
        phone: '9765432109',
        email: 'sneha.jadhav@example.com',
        exam: 'NEET / JEE',
        shift: 'morning',
        seatNumber: 7,
        fee: 499,
        paidAmount: 499,
        balanceDue: 0,
        applicationStatus: 'Approved',
        joinedDate: joined30Ago,
        expiryDate: in2DaysIST,
        cycleId: 'CYC-' + in2DaysIST,
        paymentStatus: 'Paid',
        notifications: ['Membership expires in 2 days. Automatic IST reminder queued.'],
      },
      {
        id: 'SS-1003',
        name: 'Rohan Deshmukh',
        phone: '9123456780',
        email: 'rohan.d@example.com',
        exam: 'Banking / SSC',
        shift: 'fulltime',
        seatNumber: 12,
        fee: 999,
        paidAmount: 99,
        balanceDue: 900,
        balanceDeadline: in5DaysIST,
        applicationStatus: 'Approved',
        joinedDate: joined30Ago,
        expiryDate: in2DaysIST,
        cycleId: 'CYC-' + in2DaysIST,
        paymentStatus: 'Partial Paid (₹900 Due)',
        notifications: [
          'Seat S-12 temporarily reserved via ₹99 partial lock. Pay ₹900 before deadline.',
        ],
      },
      {
        id: 'SS-1004',
        name: 'Priya Pawar',
        phone: '9988776655',
        email: 'priya.pawar@example.com',
        exam: 'CA / CS / Law',
        shift: 'afternoon',
        seatNumber: 19,
        fee: 499,
        paidAmount: 499,
        balanceDue: 0,
        applicationStatus: 'Approved',
        joinedDate: joined30Ago,
        expiryDate: in25DaysIST,
        cycleId: 'CYC-' + in25DaysIST,
        paymentStatus: 'Paid',
        notifications: ['Afternoon Shift admission verified.'],
      },
      {
        id: 'SS-1005',
        name: 'Omkar Shinde',
        phone: '9011223344',
        email: 'omkar.s@example.com',
        exam: 'UPSC / MPSC',
        shift: 'night',
        seatNumber: 25,
        fee: 499,
        paidAmount: 499,
        balanceDue: 0,
        applicationStatus: 'Approved',
        joinedDate: joined30Ago,
        expiryDate: expired2DaysAgoIST,
        cycleId: 'CYC-' + expired2DaysAgoIST,
        paymentStatus: 'Renewal Due',
        notifications: ['Membership expired. Please renew to retain Seat S-25.'],
      },
    ],
    reminders: {
      smsEnabled: true,
      whatsappEnabled: true,
      livePaidServiceApproved: false,
      smsTemplate:
        'STudy STation: Hi {name}, your {plan} for Seat {seat} expires on {expiry} (in 2 days). Renew for Rs.{amount}.',
      whatsappTemplate:
        'STudy STation: Hello {name}, your {plan} (Seat {seat}) expires on {expiry} (2 days left). Fee: ₹{amount}',
      sentCycleKeys: {},
      logs: [],
    },
    paymentGateway: {
      provider: 'Razorpay',
      mode: 'SANDBOX',
      keyId: 'rzp_test_1DP5mmOlF5G5ag',
      merchantName: 'STudy STation Reading Room',
      upiId: '8308804099@ybl',
      tokenAmount: 99,
      balanceDeadlineDays: 7,
      lockDurationMins: 10,
      allowTokenBooking: true,
      allowFullPayment: true,
      enableUpi: true,
      enableCard: true,
      enableNetbanking: true,
      enableWallets: true,
      transactions: [
        {
          txnId: 'pay_PK90412A',
          orderId: 'order_SS90412',
          signature: 'sig_hmac_88f2a9c10d4e',
          studentId: 'SS-1001',
          studentName: 'Aarav Kulkarni',
          phone: '9823456710',
          seat: 'S-04',
          purpose: 'Full-Time Reserved (Full Payment)',
          method: 'Razorpay UPI',
          amount: 999,
          status: 'Verified Paid',
          timestamp: getISTDateInfo(-2, nowMs).dateStr + ' 10:22 IST',
        },
      ],
    },
    auditLogs: [
      {
        action: 'System Initialized in Sandbox Mode (Razorpay Test)',
        timestamp: `${todayIST.dateStr} ${todayIST.timeStr}`,
      },
    ],
    animations: {
      enabled: true,
      speed: 1.0,
    },
  };
}

export function loadAppState(): AppState {
  if (typeof window === 'undefined') return createDefaultState();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      const def = createDefaultState();
      return {
        ...def,
        ...parsed,
        courses: Array.isArray(parsed.courses) && parsed.courses.length ? parsed.courses : def.courses,
        website: { ...def.website, ...(parsed.website || {}) },
        reminders: { ...def.reminders, ...(parsed.reminders || {}) },
        paymentGateway: { ...def.paymentGateway, ...(parsed.paymentGateway || {}) },
        animations: { ...def.animations, ...(parsed.animations || {}) },
        auditLogs: Array.isArray(parsed.auditLogs) ? parsed.auditLogs : def.auditLogs,
      };
    }
  } catch {
    // Fallback to seed state
  }
  return createDefaultState();
}

export function saveAppState(state: AppState): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Ignore storage quota errors
  }
}

export function generateReceiptHtml(student: MemberRecord, courses: CoursePlan[]): string {
  const ist = getISTDateInfo(0);
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Official Receipt - ${student.id}</title>
<style>
  body { font-family: system-ui, sans-serif; padding: 40px; color: #111827; background: #F8F9F5; }
  .box { max-width: 620px; margin: auto; background: #fff; border: 2px solid #1B4332; border-radius: 16px; padding: 32px; }
  h1 { color: #1B4332; margin: 0 0 4px 0; font-size: 24px; }
  p { color: #475569; margin: 0 0 16px 0; font-size: 13px; }
  table { width: 100%; border-collapse: collapse; margin-top: 20px; }
  td { padding: 10px 8px; border-bottom: 1px solid #E2E8F0; font-size: 13px; }
  .badge { display: inline-block; background: #D8F3DC; color: #1B4332; padding: 5px 12px; border-radius: 6px; font-weight: 700; font-size: 11px; }
</style>
</head>
<body>
  <div class="box">
    <h1>STudy STation Reading Room</h1>
    <p>Office No: 02, First Floor, Costa Mapal, Osmanpura, Chhatrapati Sambhajinagar - 431001</p>
    <span class="badge">VERIFIED OFFICIAL PAYMENT RECEIPT</span>
    <table>
      <tr><td><strong>Receipt / Pass ID</strong></td><td>#${student.id}</td></tr>
      <tr><td><strong>Student Name</strong></td><td>${student.name}</td></tr>
      <tr><td><strong>Mobile Number</strong></td><td>+91 ${student.phone}</td></tr>
      <tr><td><strong>Course / Shift</strong></td><td>${getShiftDisplayName(courses, student.shift)}</td></tr>
      <tr><td><strong>Seat Number</strong></td><td>${formatSeatCode(student.seatNumber)}</td></tr>
      <tr><td><strong>Total Admission Fee</strong></td><td>₹${student.fee}</td></tr>
      <tr><td><strong>Amount Paid</strong></td><td>₹${student.paidAmount ?? student.fee}</td></tr>
      <tr><td><strong>Remaining Balance</strong></td><td>₹${student.balanceDue || 0}</td></tr>
      <tr><td><strong>Valid Until</strong></td><td>${student.expiryDate}</td></tr>
    </table>
    <p style="margin-top:24px;font-size:12px;color:#64748B;">Generated via STudy STation Verified Admission System (${ist.dateStr} ${ist.timeStr}).</p>
  </div>
</body>
</html>`;
}

export function buildCsvContent(headers: string[], rows: Array<Array<string | number>>): string {
  const escapeCell = (val: string | number) => {
    const s = String(val ?? '');
    if (s.includes(',') || s.includes('"') || s.includes('\n')) {
      return `"${s.replace(/"/g, '""')}"`;
    }
    return s;
  };
  return [headers.map(escapeCell).join(','), ...rows.map((r) => r.map(escapeCell).join(','))].join('\n');
}
