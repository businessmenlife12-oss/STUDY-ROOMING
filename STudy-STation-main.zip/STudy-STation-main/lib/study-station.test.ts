import test from 'node:test';
import assert from 'node:assert/strict';
import {
  cleanExpiredTempLocks,
  computeNewExpiryDate,
  computeShiftChangeAdjustment,
  createDefaultState,
  diffDaysFromTodayIST,
  evaluateTwoDayReminders,
  formatSeatCode,
  getISTDateInfo,
  getSeatStatusForShift,
  getShiftSeatCounts,
} from './study-station';

const FIXED_NOW_MS = Date.UTC(2026, 10, 13, 6, 0, 0); // 2026-11-13T11:30 IST

test('formatSeatCode pads single digit seat numbers cleanly', () => {
  assert.equal(formatSeatCode(1), 'S-01');
  assert.equal(formatSeatCode(12), 'S-12');
  assert.equal(formatSeatCode(60), 'S-60');
});

test('IST date helpers compute offset days and 30-day expiry accurately', () => {
  const today = getISTDateInfo(0, FIXED_NOW_MS);
  const inTwoDays = getISTDateInfo(2, FIXED_NOW_MS);
  assert.equal(today.dateStr, '2026-11-13');
  assert.equal(inTwoDays.dateStr, '2026-11-15');
  assert.equal(diffDaysFromTodayIST(inTwoDays.dateStr, FIXED_NOW_MS), 2);
  assert.equal(computeNewExpiryDate('2026-11-13', 30), '2026-12-13');
});

test('full-time reservations block the seat across all shifts while shift bookings remain shift-scoped', () => {
  const state = createDefaultState(FIXED_NOW_MS);
  // S-04 is reserved by Aarav Kulkarni (fulltime)
  assert.equal(getSeatStatusForShift(state, 4, 'morning', { nowMs: FIXED_NOW_MS }).status, 'reserved');
  assert.equal(getSeatStatusForShift(state, 4, 'afternoon', { nowMs: FIXED_NOW_MS }).status, 'reserved');
  assert.equal(getSeatStatusForShift(state, 4, 'night', { nowMs: FIXED_NOW_MS }).status, 'reserved');
  assert.equal(getSeatStatusForShift(state, 4, 'fulltime', { nowMs: FIXED_NOW_MS }).status, 'reserved');

  // S-07 is reserved by Sneha Jadhav (morning only)
  assert.equal(getSeatStatusForShift(state, 7, 'morning', { nowMs: FIXED_NOW_MS }).status, 'reserved');
  assert.equal(getSeatStatusForShift(state, 7, 'afternoon', { nowMs: FIXED_NOW_MS }).status, 'available');
  // Full-time requires all shifts free, so S-07 is reserved in fulltime
  assert.equal(getSeatStatusForShift(state, 7, 'fulltime', { nowMs: FIXED_NOW_MS }).status, 'reserved');

  // S-13 is blocked across all shifts
  assert.equal(getSeatStatusForShift(state, 13, 'morning', { nowMs: FIXED_NOW_MS }).status, 'blocked');
  assert.equal(getSeatStatusForShift(state, 13, 'fulltime', { nowMs: FIXED_NOW_MS }).status, 'blocked');
});

test('temporary seat locks block other users until expiry and cleanExpiredTempLocks removes stale locks', () => {
  const state = createDefaultState(FIXED_NOW_MS);
  state.tempSeatLocks = {
    'morning|2': { expiresAt: FIXED_NOW_MS + 60000, holder: 'other' },
    'morning|3': { expiresAt: FIXED_NOW_MS - 1000, holder: 'expired' },
  };

  assert.equal(getSeatStatusForShift(state, 2, 'morning', { nowMs: FIXED_NOW_MS }).status, 'locked');
  assert.equal(
    getSeatStatusForShift(state, 2, 'morning', {
      nowMs: FIXED_NOW_MS,
      currentSelectedSeat: 2,
      currentBookingShift: 'morning',
    }).status,
    'available'
  );
  assert.equal(getSeatStatusForShift(state, 3, 'morning', { nowMs: FIXED_NOW_MS }).status, 'available');

  const cleaned = cleanExpiredTempLocks(state.tempSeatLocks, FIXED_NOW_MS);
  assert.equal(cleaned.changed, true);
  assert.ok(cleaned.nextLocks['morning|2']);
  assert.equal(cleaned.nextLocks['morning|3'], undefined);
});

test('getShiftSeatCounts totals equal totalSeats', () => {
  const state = createDefaultState(FIXED_NOW_MS);
  const morningCounts = getShiftSeatCounts(state, 'morning', FIXED_NOW_MS);
  assert.equal(morningCounts.total, 60);
  assert.equal(morningCounts.blocked, 2);
  assert.equal(morningCounts.reserved, 3); // S-04 (fulltime), S-12 (fulltime), S-07 (morning)
  assert.equal(morningCounts.available, 55);
});

test('computeShiftChangeAdjustment never charges negative fee difference on downgrade', () => {
  assert.equal(computeShiftChangeAdjustment(499, 999), 500);
  assert.equal(computeShiftChangeAdjustment(999, 499), 0);
});

test('evaluateTwoDayReminders dispatches 1 SMS + 1 WhatsApp per cycle without duplicates', () => {
  const state = createDefaultState(FIXED_NOW_MS);
  const firstRun = evaluateTwoDayReminders(state, FIXED_NOW_MS);
  // SS-1002 and SS-1003 expire in 2 days -> 2 members * 2 channels = 4 reminders
  assert.equal(firstRun.dispatchedCount, 4);
  assert.equal(firstRun.newLogs.length, 4);

  // Re-running with updated sentCycleKeys produces 0 duplicates
  state.reminders.sentCycleKeys = firstRun.nextSentCycleKeys;
  const secondRun = evaluateTwoDayReminders(state, FIXED_NOW_MS);
  assert.equal(secondRun.dispatchedCount, 0);
  assert.equal(secondRun.newLogs.length, 0);
});
