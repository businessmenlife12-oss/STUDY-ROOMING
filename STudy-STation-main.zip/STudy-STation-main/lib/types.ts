export type PrimaryView = 'visitor' | 'booking' | 'student' | 'admin';

export type AdminTabKey =
  | 'website'
  | 'payment'
  | 'seats'
  | 'available'
  | 'fulltime'
  | 'expiry'
  | 'reminders'
  | 'animations'
  | 'architecture';

export type BookingPaymentMode = 'partial' | 'full';
export type GatewayMethod = 'upi' | 'card' | 'netbanking' | 'wallets';
export type ApplicationStatus = 'Approved' | 'Rejected';

export interface CoursePlan {
  key: string;
  name: string;
  schedule: string;
  fee: number;
  badge: string;
  icon: 'sun' | 'cloud-sun' | 'moon' | 'crown' | 'book-open';
}

export interface GalleryItem {
  title: string;
  url: string;
}

export interface FaqItem {
  q: string;
  a: string;
}

export interface WebsiteSettings {
  brandName: string;
  tagline: string;
  announcement: string;
  hoursBadge: string;
  phone: string;
  address: string;
  gallery: GalleryItem[];
  faqs: FaqItem[];
}

export interface MemberRecord {
  id: string;
  name: string;
  phone: string;
  email: string;
  exam: string;
  shift: string;
  seatNumber: number;
  fee: number;
  paidAmount: number;
  balanceDue: number;
  balanceDeadline?: string | null;
  applicationStatus: ApplicationStatus;
  joinedDate: string;
  expiryDate: string;
  cycleId: string;
  paymentStatus: string;
  lastShiftChangeNote?: string;
  notifications: string[];
}

export interface ReminderLog {
  studentName: string;
  phone: string;
  cycleId: string;
  channel: 'SMS' | 'WhatsApp';
  status: string;
  timestamp: string;
}

export interface ReminderSettings {
  smsEnabled: boolean;
  whatsappEnabled: boolean;
  livePaidServiceApproved: boolean;
  smsTemplate: string;
  whatsappTemplate: string;
  sentCycleKeys: Record<string, boolean>;
  logs: ReminderLog[];
}

export interface TransactionRecord {
  txnId: string;
  orderId: string;
  signature: string;
  studentId: string;
  studentName: string;
  phone: string;
  seat: string;
  purpose: string;
  method: string;
  amount: number;
  status: 'Verified Paid' | 'Refunded';
  timestamp: string;
}

export interface PaymentGatewaySettings {
  provider: 'Razorpay' | 'Cashfree';
  mode: 'SANDBOX' | 'LIVE';
  keyId: string;
  merchantName: string;
  upiId: string;
  tokenAmount: number;
  balanceDeadlineDays: number;
  lockDurationMins: number;
  allowTokenBooking: boolean;
  allowFullPayment: boolean;
  enableUpi: boolean;
  enableCard: boolean;
  enableNetbanking: boolean;
  enableWallets: boolean;
  transactions: TransactionRecord[];
}

export interface AuditLogEntry {
  action: string;
  timestamp: string;
}

export interface TempSeatLock {
  expiresAt: number;
  holder: string;
}

export interface AnimationSettings {
  enabled: boolean;
  speed: number;
}

export interface AppState {
  darkMode: boolean;
  adminMobile: string;
  totalSeats: number;
  blockedSeats: number[];
  tempSeatLocks: Record<string, TempSeatLock>;
  courses: CoursePlan[];
  website: WebsiteSettings;
  members: MemberRecord[];
  reminders: ReminderSettings;
  paymentGateway: PaymentGatewaySettings;
  auditLogs: AuditLogEntry[];
  animations: AnimationSettings;
}

export interface SeatStatusResult {
  status: 'available' | 'reserved' | 'blocked' | 'locked';
  occupant: MemberRecord | null;
}

export interface SeatCounts {
  total: number;
  available: number;
  reserved: number;
  blocked: number;
}

export interface PaymentContext {
  contextType: 'new_booking' | 'student_balance' | 'student_renewal';
  memberId?: string;
  amount: number;
  fullFee: number;
  isPartial: boolean;
  seatNumber: number;
  shift: string;
  name: string;
  phone: string;
  email: string;
  exam?: string;
  joinedDate?: string;
  expiryDate?: string;
  purposeLabel: string;
  serverOrderId?: string;
}
