import type { Metadata } from 'next';
import { Plus_Jakarta_Sans, Playfair_Display, JetBrains_Mono } from 'next/font/google';
import './globals.css';

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700', '800'],
  variable: '--font-plus-jakarta',
  display: 'swap',
});

const playfair = Playfair_Display({
  subsets: ['latin'],
  weight: ['600'],
  style: ['normal', 'italic'],
  variable: '--font-playfair',
  display: 'swap',
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['500', '700'],
  variable: '--font-jetbrains',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'STudy STation | 24-Hour AC Reading Room, Live Seat Booking & Admin Portal',
  description:
    '24-Hour AC Reading Room & EdTech Study Center with Live Seat Booking, Razorpay/Cashfree Checkout, Student Dashboard & Admin Portal.',
  openGraph: {
    title: 'STudy STation',
    description:
      '24-Hour AC Reading Room & EdTech Study Center with Live Seat Booking, Payment Checkout, Student Dashboard & Admin Portal.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'STudy STation',
    description:
      '24-Hour AC Reading Room & EdTech Study Center with Live Seat Booking, Payment Checkout, Student Dashboard & Admin Portal.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="en"
      className={`${plusJakarta.variable} ${playfair.variable} ${jetbrainsMono.variable}`}
      suppressHydrationWarning
    >
      <body className="antialiased selection:bg-forest-900 selection:text-white" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
