import StudyStationApp from '@/components/StudyStationApp';

export default function HomePage() {
  return <StudyStationApp />;
}
