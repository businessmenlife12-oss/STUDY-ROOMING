import crypto from 'crypto';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      orderId,
      paymentId,
      signature,
      amountInr,
      mode,
    }: {
      orderId?: string;
      paymentId?: string;
      signature?: string;
      amountInr?: number;
      mode?: 'SANDBOX' | 'LIVE';
    } = body || {};

    if (!orderId || !amountInr || amountInr <= 0) {
      return NextResponse.json(
        { verified: false, error: 'Missing required order details' },
        { status: 400 }
      );
    }

    const secret = process.env.RAZORPAY_KEY_SECRET;
    if (secret && signature && paymentId && mode === 'LIVE') {
      const expected = crypto
        .createHmac('sha256', secret)
        .update(`${orderId}|${paymentId}`)
        .digest('hex');

      if (expected !== signature) {
        return NextResponse.json(
          { verified: false, error: 'HMAC-SHA256 signature verification failed' },
          { status: 400 }
        );
      }

      return NextResponse.json({
        verified: true,
        paymentId,
        signature,
        verificationMethod: 'hmac_sha256_live',
      });
    }

    const generatedPaymentId =
      paymentId || `pay_${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
    const generatedSig =
      signature ||
      `sig_hmac_${crypto
        .createHmac('sha256', secret || 'sandbox_study_station_key')
        .update(`${orderId}|${generatedPaymentId}`)
        .digest('hex')
        .slice(0, 14)}`;

    return NextResponse.json({
      verified: true,
      paymentId: generatedPaymentId,
      signature: generatedSig,
      verificationMethod: 'sandbox_hmac_sha256',
    });
  } catch {
    return NextResponse.json(
      { verified: false, error: 'Invalid payment verification payload' },
      { status: 400 }
    );
  }
}
